/* CSS Design Retrieval - single page UI (vanilla JS, no build step). */
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const FAMILY_COLOR = { site: "#0ea5b7", electrical: "#2563eb", civil: "#7c3aed", access: "#ea8a0c", cable: "#e11d48" };
const FAMILY_NAME = { site: "Site / plot", electrical: "Electrical", civil: "Civil / structure", access: "Access & ventilation", cable: "Cable routes" };
const LABEL_COLOR = { document: "#111827", substation: "#7c3aed", layout: "#9ca3af", equipment: "#2563eb", opening: "#ea8a0c",
  structure: "#6d28d9", route: "#e11d48", site_feature: "#0ea5b7", facet: "#64748b", concept: "#a3a3a3", catalogue_item: "#15803d" };
const GROUP_COLOR = { equipment: "#2563eb", door: "#ea8a0c", louvre: "#ca8a04", cutout: "#e11d48", column: "#6d28d9", beam: "#7c3aed",
  trench: "#059669", cable_tray: "#0d9488" };

async function api(path, opts = {}) {
  const r = await fetch(path, opts);
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("json") ? await r.json() : await r.text();
  if (!r.ok) throw new Error(body.detail || body || r.statusText);
  return body;
}
const postJSON = (path, data, method = "POST") => api(path, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });

/* ---------------------------------------------------------------- tabs */
const loaded = {};
function showTab(name) {
  $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  $$(".tab").forEach((t) => t.classList.toggle("active", t.id === "tab-" + name));
  if (name === "library") refreshLibrary();
  if (name === "ontology" && !loaded.onto) { loaded.onto = true; loadOntology(); }
  if (name === "site") loadSiteList();
  if (name === "review") loadReviewTab();
  if (name === "rules") loadRules();
  if (name === "admin") loadAdmin();
}
$$("#tabs button").forEach((b) => b.addEventListener("click", () => showTab(b.dataset.tab)));

async function refreshStatus() {
  try {
    const h = await api("/api/health");
    const e = h.engines.flags;
    $("#status").textContent = `${h.index.documents} drawings · ${h.index.substations} substations · index v${h.index.version} · mode ${e.retrieval_mode}` +
      ` · KG ${e.kg_enabled ? (h.engines.kg.ok ? "on" : "down") : "off"} · RAG ${e.rag_enabled ? "on" : "off"} · LLM ${h.llm.available ? h.llm.model : "not configured"}`;
  } catch (err) { $("#status").textContent = "server unreachable"; }
}

/* ---------------------------------------------------------------- chat */
const chat = { session: null, siteplan: null };

function addMsg(role, html) {
  const d = document.createElement("div");
  d.className = "msg " + role;
  d.innerHTML = html;
  $("#messages").appendChild(d);
  $("#messages").scrollTop = $("#messages").scrollHeight;
  return d;
}

async function send() {
  const text = $("#input").value.trim();
  if (!text) return;
  $("#input").value = "";
  addMsg("user", esc(text));
  const wait = addMsg("bot", '<span class="muted">matching…</span>');
  $("#send").disabled = true;
  try {
    const out = await postJSON("/api/chat", { message: text, session_id: chat.session, siteplan_id: chat.siteplan?.id || null,
      mode: $("#mode").value || null, k: 6 });
    chat.session = out.session_id;
    wait.innerHTML = esc(out.answer) + (out.search ? renderSearch(out.search) : "");
    bindResultActions(wait);
  } catch (err) {
    wait.innerHTML = `<span class="tag fail">error</span> ${esc(err.message)}`;
  }
  $("#send").disabled = false;
  $("#messages").scrollTop = $("#messages").scrollHeight;
}

function renderSearch(s) {
  const asked = (s.asked || []).map((a) => `<span class="tag">${esc(a)}</span>`).join("");
  const feas = (s.feasibility || []).map((c) => `<span class="tag ${c.status === "fail" ? "fail" : ""}">${esc(c.detail)}</span>`).join("");
  const trace = (s.trace || []).map((t) => `<div class="meta">↳ ${esc(t)}</div>`).join("");
  const engine = { kg: "Ontology KG matching", rag: "RAG matching", both: "KG + RAG merged" }[s.engine] || "no engine";
  const cards = (s.results || []).map((r, i) => resultCard(r, i)).join("");
  return `<div class="meta">${esc(engine)} · ${s.elapsed_ms} ms</div>${trace}<div class="asked">${asked}${feas}</div><div class="results">${cards || '<span class="muted">no matches</span>'}</div>`;
}

function resultCard(r, i) {
  const comps = Object.entries(r.components || {}).map(([k, v]) => `<span class="tag">${esc(k)} ${(+v).toFixed(2)}</span>`).join("");
  const checks = (r.checks || []).map((c) => `<li class="${c.status}">${esc(c.detail)}</li>`).join("");
  const expl = (r.explanation || []).slice(0, 5).map((e) => `<div class="small muted">${esc(e)}</div>`).join("");
  return `<div class="res">
    <div class="head"><span class="rank">#${i + 1}</span><span class="title">${esc(r.file_name)}</span></div>
    <div class="row small"><span class="pill ${r.verdict}">${r.verdict}</span><b>${(+r.score).toFixed(3)}</b>
      <span class="muted">${esc(r.substation_name)} · ${r.engine.toUpperCase()} · coverage ${(100 * r.coverage).toFixed(0)}%${r.status ? " · " + esc(r.status) : ""}</span></div>
    <div class="bar"><i style="width:${Math.min(100, 100 * r.score)}%"></i></div>
    ${r.overlay ? `<div class="viewtabs" data-doc="${esc(r.doc_id)}">
        <button class="vt active" data-v="overlay">Overlay on new site</button>
        ${r.overlay.equipment_layout_id ? `<button class="vt" data-v="layout" data-l="${esc(r.overlay.equipment_layout_id)}">Equipment layout</button>` : ""}
        ${r.overlay.section_layout_id ? `<button class="vt" data-v="layout" data-l="${esc(r.overlay.section_layout_id)}">Section</button>` : ""}
        ${r.overlay.site_layout_id ? `<button class="vt" data-v="layout" data-l="${esc(r.overlay.site_layout_id)}">Site plan</button>` : ""}
        <button class="vt" data-v="masks" data-p="${r.overlay.page || 1}">Masks</button></div>
      <div class="viewbody">${overlaySVG(r.overlay)}</div>` : ""}
    <div class="comps">${comps}</div>
    <ul class="checks">${checks}</ul>${expl}
    <div class="actions"><button class="btn" data-graph="${esc(r.doc_id)}">Site graph</button>
      <button class="btn" data-json="${esc(r.doc_id)}">Extraction JSON</button></div></div>`;
}

function bindViewTabs(root) {
  $$(".viewtabs", root).forEach((vt) => {
    const body = vt.nextElementSibling, doc = vt.dataset.doc, svg = body.innerHTML;
    $$(".vt", vt).forEach((b) => b.addEventListener("click", () => {
      $$(".vt", vt).forEach((x) => x.classList.toggle("active", x === b));
      if (b.dataset.v === "overlay") body.innerHTML = svg;
      else {
        const src = b.dataset.v === "masks" ? `/api/documents/${doc}/masks/${b.dataset.p}.jpg` : `/api/documents/${doc}/layout/${encodeURIComponent(b.dataset.l)}.jpg`;
        body.innerHTML = `<a href="${src}" target="_blank"><img class="drawing" src="${src}" alt="drawing" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'muted small',textContent:'no image for this view'}))"></a>`;
      }
    }));
  });
}

function bindResultActions(root) {
  bindViewTabs(root);
  $$("[data-graph]", root).forEach((b) => b.addEventListener("click", () => { showTab("site"); selectSite(b.dataset.graph); }));
  $$("[data-json]", root).forEach((b) => b.addEventListener("click", () => window.open("/api/documents/" + b.dataset.json, "_blank")));
}

/* polygons in mm, y down */
function bounds(polys) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  polys.forEach((p) => (p || []).forEach(([x, y]) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }));
  return isFinite(x0) ? [x0, y0, x1, y1] : [0, 0, 1000, 1000];
}
const pts = (p) => (p || []).map(([x, y]) => `${x.toFixed(0)},${y.toFixed(0)}`).join(" ");

function overlaySVG(o) {
  const all = [o.query_outline, o.room, ...(o.items || []).map((i) => i.coords), ...(o.query_items || []).map((i) => i.coords)];
  const [x0, y0, x1, y1] = bounds(all);
  const pad = 0.06 * Math.max(x1 - x0, y1 - y0);
  const sw = Math.max(x1 - x0, y1 - y0) / 220;
  let s = `<svg class="overlay" viewBox="${x0 - pad} ${y0 - pad} ${x1 - x0 + 2 * pad} ${y1 - y0 + 2 * pad}">`;
  (o.site_features || []).forEach((f) => {
    if (!f.coords) return;
    s += f.line ? `<polyline points="${pts(f.coords)}" fill="none" stroke="#0ea5b7" stroke-width="${sw * 2}"/>` :
      `<polygon points="${pts(f.coords)}" fill="#0ea5b733" stroke="#0ea5b7" stroke-width="${sw}"/>`;
  });
  if (o.query_outline) s += `<polygon points="${pts(o.query_outline)}" fill="none" stroke="#111827" stroke-dasharray="${sw * 4}" stroke-width="2.5"/>`;
  if (o.room) s += `<polygon points="${pts(o.room)}" fill="#7c3aed14" stroke="#7c3aed" stroke-width="${sw * 1.4}"/>`;
  (o.query_items || []).forEach((i) => { s += `<polygon points="${pts(i.coords)}" fill="#11182733" stroke="#111827" stroke-width="${sw}"/>`; });
  (o.items || []).forEach((i) => {
    const c = GROUP_COLOR[i.group] || "#64748b";
    s += (i.group === "trench" || i.group === "cable_tray") && i.coords.length < 3 ?
      `<polyline points="${pts(i.coords)}" fill="none" stroke="${c}" stroke-width="${sw * 2}"/>` :
      `<polygon points="${pts(i.coords)}" fill="${c}33" stroke="${c}" stroke-width="1.5"><title>${esc(i.label || i.cls)}</title></polygon>`;
  });
  const fs = sw * 7;
  (o.clearances || []).forEach((c, k) => {
    const col = ST_COLOR[c.status] || "#64748b";
    const hot = o.hl != null && o.hlC === c;
    s += `<g class="clx"><line x1="${c.p[0]}" y1="${c.p[1]}" x2="${c.q[0]}" y2="${c.q[1]}" stroke="${col}" stroke-width="${sw * (hot ? 2.4 : 1.2)}" stroke-dasharray="${sw * 4} ${sw * 2}"/>
      <circle cx="${c.p[0]}" cy="${c.p[1]}" r="${sw * 1.6}" fill="${col}"/><circle cx="${c.q[0]}" cy="${c.q[1]}" r="${sw * 1.6}" fill="${col}"/>`;
    if (o.labels || hot) s += `<text x="${(c.p[0] + c.q[0]) / 2}" y="${(c.p[1] + c.q[1]) / 2 - sw * 2}" text-anchor="middle" style="font-size:${fs}px;fill:${col};stroke:#fff;stroke-width:${sw * 0.9}px;paint-order:stroke">${Math.round(c.measured_mm ?? c.drawn_mm)}</text>`;
    s += "</g>";
  });
  if (o.labels) (o.items || []).forEach((i) => { if (i.group === "equipment" && i.coords.length) {
    const [a, b, c2, d] = bounds([i.coords]); s += `<text x="${(a + c2) / 2}" y="${(b + d) / 2}" text-anchor="middle" style="font-size:${fs * 0.9}px;fill:#111827">${esc(String(i.label || "").split("\n")[0].slice(0, 14))}</text>`; } });
  return s + "</svg>";
}

$("#send").addEventListener("click", send);
$("#input").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
$$(".ex").forEach((b) => b.addEventListener("click", () => { $("#input").value = b.textContent; send(); }));

$("#siteplan-file").addEventListener("change", async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append("file", f);
  const L = $("#sp-length").value;
  if (L) fd.append("known_length_mm", L);
  const chip = $("#attach-chip");
  chip.classList.remove("hidden");
  chip.innerHTML = `analysing ${esc(f.name)}…`;
  try {
    const r = await api("/api/siteplan", { method: "POST", body: fd });
    chat.siteplan = r;
    const a = r.annotated_area;
    chip.innerHTML = (r.preview_url ? `<img src="${r.preview_url}">` : "") +
      `<span>${esc(f.name)}: ${a ? esc(a.shape) + (a.length_mm ? ` ${(a.length_mm / 1000).toFixed(2)} × ${(a.width_mm / 1000).toFixed(2)} m` : " (no scale: enter long side mm and re-attach)") : esc(r.note || r.error)}` +
      `${r.features?.length ? ` · ${r.features.length} site feature(s)` : ""}</span><button title="remove">✕</button>`;
    $("button", chip).addEventListener("click", () => { chat.siteplan = null; chip.classList.add("hidden"); });
  } catch (err) { chip.innerHTML = `site plan failed: ${esc(err.message)}`; }
  e.target.value = "";
});

/* ---------------------------------------------------------------- library */
let jobTimer = null;
async function refreshLibrary() {
  const [docs, jobs] = await Promise.all([api("/api/documents"), api("/api/jobs?limit=100")]);
  renderDocs(docs);
  renderJobs(jobs);
  const active = jobs.some((j) => j.status === "queued" || j.status === "extracting");
  clearTimeout(jobTimer);
  if (active) jobTimer = setTimeout(refreshLibrary, 2500);
}

function renderJobs(jobs) {
  if (!jobs.length) { $("#jobs").innerHTML = '<span class="muted">no jobs yet</span>'; return; }
  $("#jobs").innerHTML = `<table><tr><th>file</th><th>status</th><th>stage</th><th>progress</th><th>message</th></tr>` +
    jobs.map((j) => `<tr><td>${esc(j.file_name)}</td><td><span class="st ${j.status}">${j.status}</span></td><td class="small">${esc(j.stage)}</td>
      <td><progress class="prog" max="1" value="${j.progress || 0}"></progress></td><td class="small">${esc(j.error || j.message || "")}</td></tr>`).join("") + "</table>";
}

let DOCS = [];
function renderDocs(docs) {
  DOCS = docs;
  const f = ($("#doc-filter").value || "").toLowerCase();
  const rows = docs.filter((d) => !f || d.file_name.toLowerCase().includes(f));
  $("#doc-count").textContent = `${rows.length} of ${docs.length}`;
  $("#docs").innerHTML = `<table><tr><th>drawing</th><th>status</th><th class="num">quality</th><th class="num">subs</th><th>method</th><th class="num">ver</th><th></th></tr>` +
    rows.map((d) => `<tr><td>${esc(d.file_name)}</td><td><span class="st ${d.status}">${d.status}</span></td><td class="num">${d.quality ?? ""}</td>
      <td class="num">${d.n_substations}</td><td class="small">${esc(d.method)}</td><td class="num">${d.version ?? ""}</td>
      <td><button class="btn" data-site="${d.doc_id}">view</button>
      ${d.status !== "reviewed" ? `<button class="btn" data-approve="${d.doc_id}">approve</button>` : ""}
      <button class="btn" data-del="${d.doc_id}">delete</button></td></tr>`).join("") + "</table>";
  $$("[data-site]").forEach((b) => b.addEventListener("click", () => { showTab("site"); selectSite(b.dataset.site); }));
  $$("[data-approve]").forEach((b) => b.addEventListener("click", async () => { await api(`/api/documents/${b.dataset.approve}/approve`, { method: "POST" }); refreshLibrary(); }));
  $$("[data-del]").forEach((b) => b.addEventListener("click", async () => {
    if (!confirm("Remove this drawing from the graph and index?")) return;
    await api(`/api/documents/${b.dataset.del}`, { method: "DELETE" }); refreshLibrary(); refreshStatus();
  }));
}
$("#doc-filter").addEventListener("input", () => renderDocs(DOCS));

$("#ingest-btn").addEventListener("click", async () => {
  const files = $("#ingest-files").files;
  if (!files.length) return alert("Choose PDF / DXF / DWG files first");
  const fd = new FormData();
  [...files].forEach((f) => fd.append("files", f));
  fd.append("use_v1", $("#opt-v1").checked);
  fd.append("force", $("#opt-force").checked);
  if ($("#opt-gate").value) fd.append("review_gate", $("#opt-gate").value);
  $("#ingest-btn").disabled = true;
  try { await api("/api/ingest", { method: "POST", body: fd }); } catch (err) { alert(err.message); }
  $("#ingest-btn").disabled = false;
  $("#ingest-files").value = "";
  refreshLibrary();
});
$("#import-v1").addEventListener("click", async () => {
  $("#import-v1").disabled = true;
  try { const r = await api("/api/admin/import-v1", { method: "POST" }); alert(`imported ${r.imported}, failed ${r.failed.length}, version ${r.version}`); }
  catch (err) { alert(err.message); }
  $("#import-v1").disabled = false; refreshLibrary(); refreshStatus();
});
$("#rebuild").addEventListener("click", async () => {
  $("#rebuild").disabled = true;
  try { const r = await api("/api/admin/rebuild", { method: "POST" }); alert(`re-indexed ${r.reindexed}, version ${r.version}`); }
  catch (err) { alert(err.message); }
  $("#rebuild").disabled = false; refreshLibrary(); refreshStatus();
});

/* ---------------------------------------------------------------- tree view (original design-graph layout) */
function treeView(container, root, opts = {}) {
  const ROW = 30, PADX = 16, CH = 6.9, MAXW = 330, GAP = 44;
  const collapsed = new Set();
  (function init(n) { if (n.collapsed) collapsed.add(n.id); (n.children || []).forEach(init); })(root);
  let selected = null;
  function render(target = container, bind = true) {
    const rows = [], widths = [];
    (function place(n, d) {
      n._d = d;
      const extra = (n.children?.length ? 3 : 0) + (collapsed.has(n.id) && n.children?.length ? String(n.children.length).length + 4 : 0);
      n._w = Math.min(MAXW, Math.max(80, (n.label.length + extra + 1) * CH + 2 * PADX));
      widths[d] = Math.max(widths[d] || 0, n._w);
      const kids = collapsed.has(n.id) ? [] : (n.children || []);
      if (!kids.length) { n._y = rows.length * ROW + ROW; rows.push(n); }
      else { kids.forEach((c) => place(c, d + 1)); n._y = (kids[0]._y + kids[kids.length - 1]._y) / 2; }
      n._kids = kids;
    })(root, 0);
    const xs = [16]; widths.forEach((w, i) => (xs[i + 1] = xs[i] + w + GAP));
    const W = xs[widths.length] + 16, H = rows.length * ROW + ROW;
    let links = "", boxes = "";
    (function draw(n) {
      const x = xs[n._d], y = n._y, c = (n.family && FAMILY_COLOR[n.family]) || "#64748b";
      n._kids.forEach((k) => {
        const x1 = x + n._w, x2 = xs[k._d], mx = (x1 + x2) / 2;
        links += `<path d="M${x1} ${y}C${mx} ${y} ${mx} ${k._y} ${x2} ${k._y}" fill="none" stroke="${c}" stroke-opacity=".45" stroke-width="1.2"/>`;
        draw(k);
      });
      const hasKids = (n.children || []).length > 0, folded = collapsed.has(n.id);
      const maxc = Math.floor((n._w - 2 * PADX) / CH) - (hasKids ? 3 : 0) - (folded ? String(n.children.length).length + 4 : 0);
      const label = n.label.length > maxc ? n.label.slice(0, maxc - 1) + "…" : n.label;
      boxes += `<g class="node" data-id="${esc(n.id)}"><rect x="${x}" y="${y - 11}" width="${n._w}" height="22" rx="6"
        fill="${c}" fill-opacity="${n.id === selected ? 0.28 : n._d === 0 ? 0.2 : 0.09}" stroke="${c}" stroke-width="${n.id === selected ? 2 : 1}"/>
        <text x="${x + PADX - 6}" y="${y + 4}" fill="currentColor">${hasKids ? (folded ? "▸ " : "▾ ") : ""}${esc(label)}${folded ? ` (+${n.children.length})` : ""}</text>
        <title>${esc(n.label)}</title></g>`;
    })(root);
    target.innerHTML = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" style="color:var(--ink)">${links}${boxes}</svg>`;
    if (!bind) return;
    const byId = new Map(); (function idx(n) { byId.set(n.id, n); (n.children || []).forEach(idx); })(root);
    $$("g.node", container).forEach((g) => g.addEventListener("click", () => {
      const n = byId.get(g.dataset.id);
      selected = n.id;
      if ((n.children || []).length) { collapsed.has(n.id) ? collapsed.delete(n.id) : collapsed.add(n.id); }
      render();
      opts.onSelect && opts.onSelect(n);
    }));
  }
  render();
  return {
    expandAll() { collapsed.clear(); render(); },
    /* the whole tree, every branch open, as an <svg> element detached from the page (for PNG export) */
    snapshot(open = true) {
      const saved = new Set(collapsed), sel = selected;
      if (open) collapsed.clear();
      const tmp = document.createElement("div");
      render(tmp, false);
      collapsed.clear(); saved.forEach((x) => collapsed.add(x)); selected = sel; render();
      return tmp.firstElementChild;
    },
    collapseTo(depth) { collapsed.clear(); (function c(n, d) { if (d >= depth && (n.children || []).length) collapsed.add(n.id); (n.children || []).forEach((k) => c(k, d + 1)); })(root, 0); render(); },
  };
}

/* Save an <svg> as a PNG (white background, fixed colours; CSS variables do not exist outside the page).
   Everything goes through Blob URLs (no data-URL size limit). The result is announced next to the button, with links to open the
   image or fetch the SVG, because some embedded browsers ignore <a download>. */
function svgStandalone(svg) {
  const el = svg.cloneNode(true);
  const vb = (el.getAttribute("viewBox") || "").split(/[\s,]+/).map(Number);
  const w = +el.getAttribute("width") || vb[2] || svg.clientWidth || 1200, h = +el.getAttribute("height") || vb[3] || svg.clientHeight || 800;
  el.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  el.setAttribute("width", w); el.setAttribute("height", h);
  if (vb.length !== 4 || vb.some(isNaN)) el.setAttribute("viewBox", `0 0 ${w} ${h}`);
  el.style.color = "#1d2433";
  const [vx, vy, vw, vh] = (el.getAttribute("viewBox") || "").split(/[\s,]+/).map(Number);
  el.insertAdjacentHTML("afterbegin", `<style>text{font:12px system-ui,-apple-system,'Segoe UI',Arial,sans-serif;fill:#1d2433}</style>` +
    `<rect x="${vx}" y="${vy}" width="${vw}" height="${vh}" fill="#ffffff"/>`);
  return { text: '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(el), w, h };
}
function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.style.display = "none";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 120000);
  return url;
}
function exportSVG(svg, filename, msgEl, scale = 2) {
  const say = (html) => { if (msgEl) msgEl.innerHTML = html; };
  if (!svg) { say('<span class="err">Nothing to export yet. Open a graph first.</span>'); return; }
  let st;
  try { st = svgStandalone(svg); } catch (e) { say(`<span class="err">Could not read the graph: ${esc(e.message)}</span>`); return; }
  const svgBlob = new Blob([st.text], { type: "image/svg+xml;charset=utf-8" });
  const asSvg = (why) => {
    const url = saveBlob(svgBlob, filename.replace(/\.png$/i, ".svg"));
    say(`<span class="err">${esc(why)}</span> Saved as SVG instead (opens in any browser, Word and PowerPoint). <a href="${url}" target="_blank">open</a>`);
  };
  const k = Math.max(0.25, Math.min(scale, 16000 / Math.max(st.w, st.h), Math.sqrt(1.0e8 / (st.w * st.h))));
  const img = new Image();
  const src = URL.createObjectURL(svgBlob);
  img.onload = () => {
    try {
      const c = document.createElement("canvas");
      c.width = Math.round(st.w * k); c.height = Math.round(st.h * k);
      const g = c.getContext("2d");
      g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height);
      g.drawImage(img, 0, 0, c.width, c.height);
      c.toBlob((b) => {
        URL.revokeObjectURL(src);
        if (!b) return asSvg("The image was too large for the browser to make a PNG.");
        const url = saveBlob(b, filename);
        say(`Saved <b>${esc(filename)}</b> (${c.width}×${c.height}px). Nothing in your downloads? <a href="${url}" target="_blank">open the image</a> and save it from there, or <a href="#" class="dl-svg">get the SVG</a>.`);
        const l = msgEl && msgEl.querySelector(".dl-svg");
        if (l) l.addEventListener("click", (ev) => { ev.preventDefault(); saveBlob(svgBlob, filename.replace(/\.png$/i, ".svg")); });
      }, "image/png");
    } catch (e) { URL.revokeObjectURL(src); asSvg("The browser would not turn the graph into a PNG (" + e.message + ").") }
  };
  img.onerror = () => { URL.revokeObjectURL(src); asSvg("The browser could not draw the graph image."); };
  img.src = src;
  say("Preparing the image…");
}
const downloadSVGasPNG = (svg, filename, msgEl) => exportSVG(svg, filename, msgEl);

function propsTable(obj) {
  return `<table>${Object.entries(obj || {}).filter(([k, v]) => v !== null && v !== "" && typeof v !== "object")
    .map(([k, v]) => `<tr><td class="muted">${esc(k)}</td><td>${esc(v)}</td></tr>`).join("")}</table>` +
    Object.entries(obj || {}).filter(([k, v]) => v && typeof v === "object").map(([k, v]) => `<div class="muted">${esc(k)}</div><pre>${esc(JSON.stringify(v))}</pre>`).join("");
}

/* ---------------------------------------------------------------- network view (optional) */
function forceLayout(nodes, edges, W, H, iters = 320) {
  const idx = new Map(nodes.map((n, i) => [n.id, i]));
  nodes.forEach((n, i) => { n.x = W / 2 + Math.cos(i) * W * 0.3 * Math.random(); n.y = H / 2 + Math.sin(i) * H * 0.3 * Math.random(); n.vx = 0; n.vy = 0; });
  const E = edges.map((e) => [idx.get(e.out), idx.get(e.in)]).filter(([a, b]) => a !== undefined && b !== undefined);
  const k = Math.sqrt((W * H) / Math.max(nodes.length, 1)) * 0.7;
  for (let t = 0; t < iters; t++) {
    const temp = 1 - t / iters;
    for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i], b = nodes[j]; const dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy + 0.01, f = (k * k) / d2 * 0.05;
      a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f;
    }
    E.forEach(([i, j]) => { const a = nodes[i], b = nodes[j], dx = b.x - a.x, dy = b.y - a.y, d = Math.sqrt(dx * dx + dy * dy) + 0.01, f = (d - k) / d * 0.08;
      a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f; });
    nodes.forEach((n) => { n.vx += (W / 2 - n.x) * 0.002; n.vy += (H / 2 - n.y) * 0.002;
      const v = Math.hypot(n.vx, n.vy), cap = 12 * temp + 0.5; if (v > cap) { n.vx *= cap / v; n.vy *= cap / v; }
      n.x = Math.max(30, Math.min(W - 30, n.x + n.vx)); n.y = Math.max(20, Math.min(H - 20, n.y + n.vy)); n.vx *= 0.6; n.vy *= 0.6; });
  }
}

function networkView(container, nodes, edges, onSelect) {
  const W = Math.max(900, container.clientWidth - 4), H = 680;
  forceLayout(nodes, edges, W, H);
  const pos = new Map(nodes.map((n) => [n.id, n]));
  const named = new Set(["document", "substation", "equipment"]);
  let s = "";
  edges.forEach((e) => { const a = pos.get(e.out), b = pos.get(e.in); if (a && b)
    s += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#94a3b8" stroke-opacity=".45"><title>${esc(e.label)}</title></line>`; });
  nodes.forEach((n, i) => {
    const r = n.label === "substation" || n.label === "document" ? 9 : 6;
    const c = (n.family && FAMILY_COLOR[n.family]) || LABEL_COLOR[n.label] || "#64748b";
    s += `<g class="node" data-i="${i}"><circle cx="${n.x}" cy="${n.y}" r="${r}" fill="${c}" stroke="#fff"><title>${esc(n.label)}: ${esc(n.name)}</title></circle>
      ${named.has(n.label) ? `<text x="${n.x + r + 3}" y="${n.y + 4}" fill="currentColor" style="font-size:11px">${esc(String(n.name).slice(0, 18))}</text>` : ""}</g>`;
  });
  container.innerHTML = `<svg width="${W}" height="${H}" style="color:var(--ink)">${s}</svg>`;
  $$("g.node", container).forEach((g) => g.addEventListener("click", () => onSelect(nodes[+g.dataset.i])));
}

/* ---------------------------------------------------------------- ontology */
let ONTO = null;
async function loadOntology() {
  const o = await api("/api/ontology");
  ONTO = treeView($("#onto-tree"), o.view, { onSelect: (n) => {
    $("#onto-info").innerHTML = n.info ? ontoInfoHTML(n.info, o.types) : `<h3>${esc(n.label)}</h3>${propsTable(n.detail)}`;
  } });
  ONTO.collapseTo(2);
  $("#onto-meta").innerHTML = `<div class="legend">${Object.entries(FAMILY_NAME).map(([k, v]) => `<span style="--c:${FAMILY_COLOR[k]}">${v}</span>`).join("")}</div>` +
    `vertex labels: ${o.vertex_labels.join(", ")} · edge labels: ${o.edge_labels.join(", ")}`;
}
const TYPE_COLOR = { string: "#64748b", integer: "#0d9488", number: "#0d9488", boolean: "#a16207", enum: "#7c3aed", point: "#2563eb", polygon: "#2563eb",
  polyline: "#2563eb", bbox: "#2563eb", mask: "#e11d48", list: "#64748b", object: "#64748b" };
const typeBadge = (t, types) => `<span class="ty" style="--c:${TYPE_COLOR[t] || "#64748b"}" title="${esc((types || TYPES_HELP)[t] || "")}">${esc(t)}</span>`;
let TYPES_HELP = {};
function ontoInfoHTML(i, types) {
  TYPES_HELP = types || TYPES_HELP;
  const fam = i.family ? `<span class="mk" style="--c:${FAMILY_COLOR[i.family] || "#888"}">${esc(FAMILY_NAME[i.family] || i.family)}</span>` : "";
  return `<h3>${esc(i.label)}</h3><div class="small">${fam} <span class="muted">class</span> <code>${esc(i.id)}</code>${i.vertex ? ` &middot; <span class="muted">graph vertex</span> <code>${esc(i.vertex)}</code>` : ""}</div>
    <p>${esc(i.what)}</p>
    ${i.how ? `<h4>How it is extracted</h4><p class="small">${esc(i.how)}</p>` : ""}
    ${i.fields.length ? `<h4>Values it carries</h4><table class="ft"><tr><th>value</th><th>type</th><th>unit</th></tr>${i.fields.map((f) =>
      `<tr><td><code>${esc(f.name)}</code><div class="muted small">${esc(f.desc)}</div></td><td>${typeBadge(f.type, types)}</td><td class="small">${esc(f.unit)}</td></tr>`).join("")}</table>` : ""}
    ${i.uses.length ? `<h4>Used for</h4><ul class="small">${i.uses.map((u) => `<li><b>${esc(u.key)}</b>${u.desc ? ": " + esc(u.desc) : ""}</li>`).join("")}</ul>` : ""}
    ${i.children.length ? `<h4>Sub-classes</h4><div class="small">${i.children.map(esc).join(", ")}</div>` : ""}
    <div class="muted small" style="margin-top:8px">${i.instances} instance(s) in the graph</div>`;
}
$("#onto-expand").addEventListener("click", () => ONTO && ONTO.expandAll());
$("#onto-png").addEventListener("click", () => exportSVG(ONTO ? ONTO.snapshot($("#onto-png-open").checked) : null, "ontology-graph.png", $("#onto-msg")));
$("#onto-collapse").addEventListener("click", () => ONTO && ONTO.collapseTo(1));

/* ---------------------------------------------------------------- site */
async function loadSiteList() {
  const docs = DOCS.length ? DOCS : await api("/api/documents");
  DOCS = docs;
  const sel = $("#site-doc"), cur = sel.value;
  sel.innerHTML = docs.map((d) => `<option value="${d.doc_id}">${esc(d.file_name)}</option>`).join("");
  if (cur) sel.value = cur;
  if (sel.value && !loaded.site) { loaded.site = true; selectSite(sel.value); }
}
$("#site-doc").addEventListener("change", (e) => selectSite(e.target.value));
$("#site-view").addEventListener("change", () => selectSite($("#site-doc").value));
$("#hide-concepts").addEventListener("change", () => selectSite($("#site-doc").value));
$("#hide-layouts").addEventListener("change", () => selectSite($("#site-doc").value));

const fmtm = (v) => (v ? (v / 1000).toFixed(2) + " m" : "–");
function summaryHTML(s) {
  const md = s.metadata, q = s.quality || {};
  const kv = (k, v) => (v === null || v === undefined || v === "" ? "" : `<tr><td class="muted">${esc(k)}</td><td>${esc(v)}</td></tr>`);
  let h = `<table>${kv("drawing", s.file_name)}${kv("extraction", s.method)}${kv("quality", `${q.score} (${q.status})`)}
    ${kv("installation", md.installation)}${kv("arrangement", md.arrangement)}${kv("context", md.context)}${kv("floor", md.floor)}
    ${kv("location", md.location_in_building)}${kv("voltage", md.voltage_kv ? md.voltage_kv + " kV" : "")}${kv("substations", md.substation_count)}${kv("kind", md.kind)}</table>`;
  s.substations.forEach((u) => {
    h += `<h4>${esc(u.name)}${u.floor ? " · " + esc(u.floor) : ""}</h4><table>
      ${kv("equipment", Object.entries(u.counts || {}).map(([k, v]) => `${v} ${k}`).join(", "))}
      ${kv("transformer kVA", u.kva.join(" / ") + (u.kva_from_catalogue ? ` (${u.kva_from_catalogue} from catalogue)` : ""))}
      ${kv("room", `${fmtm(u.length_mm)} × ${fmtm(u.width_mm)} · ${u.area_m2 ?? "–"} m² · ${u.shape || ""}`)}
      ${kv("clear height", u.clear_height_mm ? u.clear_height_mm + " mm" : "")}${kv("slab to soffit", u.slab_to_soffit_mm)}
      ${kv("beam bottom", u.beam_bottom_mm)}${kv("plinth / platform", u.plinth_mm)}${kv("trench depth", u.trench_depth_mm)}
      ${kv("doors", u.doors.join(", "))}${kv("louvres / cutouts / beams / routes", `${u.n_louvres} / ${u.n_cutouts} / ${u.n_beams} / ${u.n_routes}`)}
      ${kv("scale", u.mm_per_px ? u.mm_per_px.toFixed(2) + " mm/px" : "")}${kv("section used", u.section_reason)}</table>`;
  });
  const f = s.site;
  h += `<h4>Site plan</h4><table>${kv("features", Object.entries(f.features).map(([k, v]) => `${v} ${k}`).join(", ") || "none extracted")}
    ${kv("scaled", f.scaled ? "yes" : "no (distances not measurable)")}</table>`;
  if (f.clearance_checks.length) h += `<div>${f.clearance_checks.map((c) => `<span class="tag ${c.meets_norm ? "" : "fail"}">${esc(c.feature)} ${(c.distance_mm / 1000).toFixed(1)} m / norm ${(c.norm_mm / 1000).toFixed(1)} m</span>`).join(" ")}</div>`;
  return h;
}

const ST_COLOR = { fail: "#dc2626", pass: "#16a34a", "no rule": "#94a3b8" };
let SITE = null;   // { docId, sum, geo }
$$("#site-tabs button").forEach((b) => b.addEventListener("click", () => showSiteTab(b.dataset.st)));
function showSiteTab(name) {
  $$("#site-tabs button").forEach((b) => b.classList.toggle("active", b.dataset.st === name));
  $$(".subtab").forEach((t) => t.classList.toggle("active", t.id === "st-" + name));
}
$("#site-png").addEventListener("click", () => exportSVG($("#site-graph svg"), "site-graph.png", $("#site-msg")));
["geo-cl", "geo-cl-fail", "geo-labels"].forEach((id) => $("#" + id).addEventListener("change", () => SITE && renderGeometry()));

function renderGeometry() {
  const on = $("#geo-cl").checked, failOnly = $("#geo-cl-fail").checked, labels = $("#geo-labels").checked;
  $("#geo-cl-fail").disabled = !on;
  $("#site-geom").innerHTML = SITE.geo.substations.map((s) => {
    const cl = on ? s.clearances.filter((c) => c.p && c.q && (!failOnly || c.status === "fail")) : [];
    return `<div class="card"><b>${esc(s.name)}</b> <span class="muted small">${on ? `${cl.length} clearance line(s) shown` : "clearances hidden"}</span>
     ${s.room ? overlaySVG({ room: s.room, items: s.items, clearances: cl, labels }) : '<div class="muted">no room geometry</div>'}
     <details class="small"><summary>Equipment (${s.equipment.length})</summary>
     <table><tr><th>label</th><th>type</th><th class="num">kVA</th><th>kVA source</th><th class="num">L×B×H mm</th></tr>${s.equipment.map((e) =>
       `<tr><td>${esc(e.label)}</td><td>${esc(e.equipment_type)}</td><td class="num">${e.kva ?? ""}</td><td class="small">${esc(e.kva_source || "")}</td>
        <td class="num">${[e.L_mm, e.B_mm, e.H_mm].map((v) => (v ? Math.round(v) : "–")).join("×")}</td></tr>`).join("")}</table></details></div>`;
  }).join("") || '<div class="card muted">No substation geometry was extracted for this drawing.</div>';
}

function renderClearances() {
  const mm = (v) => (v == null ? "–" : Math.round(v));
  $("#site-clear").innerHTML = SITE.geo.substations.map((s, si) => {
    const n = (k) => s.clearances.filter((c) => c.status === k).length;
    return `<div class="card" data-si="${si}"><div class="row"><b>${esc(s.name)}</b>
      <span class="tag fail">${n("fail")} fail</span><span class="tag">${n("pass")} pass</span><span class="tag">${n("no rule")} no rule</span>
      <span class="spacer"></span>
      <select class="cl-st"><option value="">all status</option><option>fail</option><option>pass</option><option>no rule</option></select>
      <select class="cl-kind"><option value="">equipment + walls</option><option value="equipment">equipment ↔ equipment</option><option value="wall">equipment ↔ wall</option></select></div>
      <div class="cl-grid"><div class="cl-map"></div><div class="cl-tab"></div></div>
      <div class="muted small">Needs = the larger of the two items' smallest side clearance in the rule table (indicative; direction of the clearance is not used). Drawn = dimension printed on the drawing, measured = gap between the extracted footprints.</div></div>`;
  }).join("") || '<div class="card muted">No clearances were captured for this drawing.</div>';
  $$("#site-clear .card[data-si]").forEach((card) => {
    const s = SITE.geo.substations[+card.dataset.si];
    let hl = null;
    const draw = () => {
      const st = $(".cl-st", card).value, kd = $(".cl-kind", card).value;
      const rows = s.clearances.filter((c) => (!st || c.status === st) && (!kd || c.kind === kd));
      // map: failing gaps and the selected row (or exactly the rows of a chosen status), so it stays readable
      const lines = (st || kd ? rows : rows.filter((c) => c.status === "fail")).concat(hl != null && !rows.includes(s.clearances[hl]) ? [s.clearances[hl]] : []);
      $(".cl-map", card).innerHTML = s.room ? overlaySVG({ room: s.room, items: s.items, clearances: lines.filter((c) => c.p && c.q), hl, hlC: hl != null ? s.clearances[hl] : null, labels: true }) : "";
      $(".cl-tab", card).innerHTML = `<table class="clt"><tr><th>between</th><th class="num">drawn</th><th class="num">measured</th><th class="num">needs</th><th class="num">margin</th><th>status</th><th></th></tr>${rows.map((c) => {
        const i = s.clearances.indexOf(c);
        const rl = [c.rule_a, c.rule_b].filter(Boolean).map((r) => r.title).join(" · ");
        return `<tr data-i="${i}" class="${i === hl ? "sel" : ""}"><td>${esc(c.a)} <span class="muted">↔</span> ${esc(c.b)}<div class="muted small">${esc(c.kind)}${rl ? " · rule: " + esc(rl) : ""}</div></td>
          <td class="num">${mm(c.drawn_mm)}</td><td class="num">${mm(c.measured_mm)}</td><td class="num">${mm(c.required_mm)}</td>
          <td class="num" style="color:${c.margin_mm < 0 ? ST_COLOR.fail : "inherit"}">${mm(c.margin_mm)}</td>
          <td><span class="tag" style="border-color:${ST_COLOR[c.status]};color:${ST_COLOR[c.status]}">${esc(c.status)}</span></td>
          <td><button class="btn small cl-show" data-id="${esc(s.id)}:cl:${esc(c.a)}:${esc(c.b)}">Inspect</button></td></tr>`;
      }).join("") || '<tr><td colspan="7" class="muted">nothing matches</td></tr>'}</table>`;
      $$(".cl-show", card).forEach((b) => b.addEventListener("click", (ev) => { ev.stopPropagation(); openInReview(SITE.docId, b.dataset.id); }));
      $$("tr[data-i]", card).forEach((tr) => tr.addEventListener("click", () => { hl = hl === +tr.dataset.i ? null : +tr.dataset.i; draw(); }));
    };
    $$("select", card).forEach((x) => x.addEventListener("change", draw));
    draw();
  });
}

async function selectSite(docId) {
  if (!docId) return;
  if ($("#site-doc").value !== docId) { if (!DOCS.length) await loadSiteList(); $("#site-doc").value = docId; }
  const view = $("#site-view").value;
  $("#net-opts").classList.toggle("hidden", view !== "network");
  const [sum, geo] = await Promise.all([api(`/api/documents/${docId}/summary`), api(`/api/documents/${docId}/geometry`)]);
  SITE = { docId, sum, geo };
  // the graph is optional: geometry, clearances and the drawing must still show when the drawing is not in the graph yet
  let g = null, gerr = "";
  try { g = await api(`/api/documents/${docId}/graph`); } catch (e) { gerr = e.message; }
  const props = new Map((g ? g.nodes : []).map((n) => [n.id, n]));
  const show = (vid, fallback) => {
    const n = props.get(vid);
    $("#node-info").innerHTML = n ? `<h3>${esc(n.label)}</h3><div class="muted">${esc(n.id)}</div>${propsTable(n.props)}` : (fallback || "");
  };
  $("#site-meta").textContent = `${g ? `${g.nodes.length} vertices · ${g.edges.length} edges · ` : ""}quality ${sum.quality.score} (${sum.quality.status})`;
  if (!g) {
    $("#site-graph").innerHTML = `<div class="muted small" style="padding:12px">This drawing is not in the graph yet (${esc(gerr)}). Geometry, clearances and the drawing are still available in the other tabs. Load it with <code>sr rebuild</code> or <code>sr extract-all --index</code>.</div>`;
  } else if (view === "tree") {
    const tree = await api(`/api/documents/${docId}/tree`);
    treeView($("#site-graph"), tree, { onSelect: (n) => show(n.vid, `<h3>${esc(n.label)}</h3>`) });
  } else {
    let nodes = g.nodes, edges = g.edges;
    if ($("#hide-concepts").checked) nodes = nodes.filter((n) => n.label !== "concept");
    if ($("#hide-layouts").checked) nodes = nodes.filter((n) => n.label !== "layout");
    const keep = new Set(nodes.map((n) => n.id));
    edges = edges.filter((e) => keep.has(e.out) && keep.has(e.in));
    networkView($("#site-graph"), nodes, edges, (n) => show(n.id));
  }
  $("#node-info").innerHTML = summaryHTML(sum);
  renderGeometry();
  renderClearances();
  renderValues(docId);
}
async function renderValues(docId) {
  const box = $("#site-values");
  box.innerHTML = '<div class="card muted">Loading values…</div>';
  let D;
  try { D = await api(`/api/documents/${docId}/review`); } catch (e) { box.innerHTML = `<div class="card err">Could not load values: ${esc(e.message)}</div>`; return; }
  SITE.values = D;
  drawValues();
}
function drawValues() {
  const D = SITE && SITE.values; if (!D) return;
  const q = ($("#val-q").value || "").toLowerCase();
  const sect = (title, items) => {
    const rows = items.map((it) => (it.values || []).filter((v) => !q || `${it.label} ${v.name} ${v.summary}`.toLowerCase().includes(q)).map((v) =>
      `<tr><td>${esc(it.label)}</td><td><code>${esc(v.name)}</code></td><td>${esc(v.summary)}${v.unit ? ` <span class="muted small">${esc(v.unit)}</span>` : ""}</td>
       <td>${typeBadge(v.type, D.types)}</td><td><button class="btn small" data-item="${esc(it.id)}">Show</button></td></tr>`).join("")).join("");
    return rows ? `<details class="card" open><summary><b>${esc(title)}</b></summary><table class="ft"><tr><th>item</th><th>value</th><th>extracted</th><th>type</th><th></th></tr>${rows}</table></details>` : "";
  };
  const html = D.groups.map((g) => sect(g.label, g.items)).join("") + sect("Clearances", D.clearances || []);
  $("#site-values").innerHTML = html || '<div class="card muted">Nothing captured for this drawing.</div>';
  $$("#site-values button[data-item]").forEach((b) => b.addEventListener("click", () => openInReview(SITE.docId, b.dataset.item)));
}
$("#val-q").addEventListener("input", drawValues);
const MASK_RGB = { room: "#28a03c", site_boundary: "#dc2828", equipment: "#2563eb", door: "#ea8a0c", rolling_shutter: "#e66e00", fire_exit: "#c83c3c",
  ventilation: "#b7a50e", cutout: "#e11d5d", beam: "#7c3aed", column: "#6e2894", trench: "#1d9e75", cable_tray: "#78b475", access_path: "#e6c800",
  wayleave: "#e6c800", nalla: "#1478c8", tree: "#288c28" };
const maskColor = (c) => MASK_RGB[c] || "#888";


/* ---------------------------------------------------------------- review: inspect what was captured, mark it right or wrong */
const RV = { data: null, marks: {}, sel: null, page: 1, zoom: 1, layer: "all", vfilter: "", shown: [] };
const PRECISION_TXT = { exact: "exact box on the drawing", segment: "the only mask of its class (no box of its own)", layout: "approximate: only the layout it was read from is known", none: "location not recorded" };
const VERDICT = { correct: ["✓", "#16a34a", "correct"], wrong: ["✗", "#dc2626", "wrong"], unsure: ["?", "#d97706", "unsure"] };
const KIND_LAYER = { room: "room", equipment: "equipment", opening: "openings", cutout: "routes", route: "routes", structure: "structures", site_feature: "site",
  equipment_gap: "clearances", wall_gap: "clearances", ceiling_clearance: "clearances", plot_clearance: "clearances" };
const LAYER_NAME = { all: "Everything", room: "Room outline", equipment: "Equipment", clearances: "Clearances", openings: "Doors, shutters, louvres", routes: "Cut-outs, trenches, trays",
  structures: "Beams and columns", site: "Site features (plot)", masks: "All masks" };

async function loadReviewTab() {
  if (!DOCS.length) DOCS = await api("/api/documents");
  const sel = $("#rv-doc"), cur = sel.value;
  sel.innerHTML = DOCS.map((d) => `<option value="${d.doc_id}">${esc(d.file_name)}</option>`).join("");
  if (cur) sel.value = cur;
  if (sel.value && (!RV.data || RV.data.doc_id !== sel.value)) await loadReview(sel.value);
}
async function loadReview(docId) {
  try {
    const [data, m] = await Promise.all([api(`/api/documents/${docId}/review`), api(`/api/documents/${docId}/review-marks`).catch(() => ({ marks: {} }))]);
    RV.data = data; RV.marks = m.marks || {};
  } catch (e) { $("#rv-list").innerHTML = `<div class="err">Could not load this drawing for review: ${esc(e.message)}</div>`; return; }
  RV.sel = null; RV.zoom = 1;
  $("#rv-doc").value = docId;
  const D = RV.data;
  TYPES_HELP = D.types;
  const first = D.pages.find((p) => p.has_image) || D.pages[0];
  RV.page = first ? first.page : 1;
  $("#rv-page").innerHTML = D.pages.map((p) => `<option value="${p.page}" ${p.page === RV.page ? "selected" : ""}>page ${p.page}${p.has_image ? "" : " (no image)"}</option>`).join("");
  const counts = {};
  D.segments.forEach((s) => { counts[s.cls] = (counts[s.cls] || 0) + 1; });
  const present = new Set(rvAll().map((i) => KIND_LAYER[i.kind]));
  const opts = [["all", `Everything`]].concat(["room", "equipment", "clearances", "openings", "routes", "structures", "site"].filter((k) => present.has(k)).map((k) => [k, LAYER_NAME[k]]));
  if (D.segments.length) opts.push(["masks", `All masks (${D.segments.length})`], ...Object.entries(counts).map(([c, n]) => [`mask:${c}`, `Mask · ${c} (${n})`]));
  $("#rv-layer").innerHTML = opts.map(([v, t]) => `<option value="${esc(v)}">${esc(t)}</option>`).join("");
  RV.layer = "all"; $("#rv-layer").value = "all";
  renderReview();
  renderDetail();
}
const rvAll = () => (RV.data ? RV.data.groups.flatMap((g) => g.items).concat(RV.data.clearances) : []);
const verdictOf = (id) => (RV.marks[id] && RV.marks[id].verdict) || "";
function layerShows(layer, kindLayer) { return layer === "all" || layer === kindLayer || (layer === "masks" || layer.startsWith("mask:") ? false : false); }
function rvVisible() {            // the items the current layer, verdict filter and search let through
  const q = ($("#rv-filter").value || "").toLowerCase(), vf = RV.vfilter;
  return rvAll().filter((i) => {
    if (RV.layer !== "all" && RV.layer !== KIND_LAYER[i.kind]) return false;
    const v = verdictOf(i.id);
    if (vf === "none" ? v : vf && v !== vf) return false;
    return !q || `${i.label} ${i.class || ""} ${i.class_label || ""} ${i.kind}`.toLowerCase().includes(q);
  });
}
function rvSegments() {
  if (!(RV.layer === "all" || RV.layer === "masks" || RV.layer.startsWith("mask:"))) return [];
  const q = ($("#rv-filter").value || "").toLowerCase(), vf = RV.vfilter;
  return RV.data.segments.filter((s) => {
    if (RV.layer.startsWith("mask:") && s.cls !== RV.layer.slice(5)) return false;
    const v = verdictOf("seg:" + s.id);
    if (vf === "none" ? v : vf && v !== vf) return false;
    return !q || `${s.cls} ${s.label || ""} ${s.source || ""} ${s.legend || ""}`.toLowerCase().includes(q);
  });
}
function renderReview() { renderProgress(); renderReviewList(); drawReview(); }
function renderProgress() {
  const all = rvAll(), n = all.length, c = { correct: 0, wrong: 0, unsure: 0 };
  all.forEach((i) => { const v = verdictOf(i.id); if (c[v] !== undefined) c[v]++; });
  const done = c.correct + c.wrong + c.unsure;
  $("#rv-bar-ok").style.width = (n ? 100 * c.correct / n : 0) + "%";
  $("#rv-bar-bad").style.width = (n ? 100 * c.wrong / n : 0) + "%";
  $("#rv-bar-unsure").style.width = (n ? 100 * c.unsure / n : 0) + "%";
  const segMarks = Object.keys(RV.marks).filter((k) => k.startsWith("seg:")).length;
  $("#rv-prog").textContent = `${done} of ${n} items reviewed · ${c.correct} correct · ${c.wrong} wrong · ${c.unsure} unsure` + (segMarks ? ` · ${segMarks} mask(s) marked` : "");
}
function renderReviewList() {
  const D = RV.data;
  const row = (i) => { const v = verdictOf(i.id);
    return `<div class="rv-row ${RV.sel === i.id ? "sel" : ""}" data-id="${esc(i.id)}"><span class="vd" style="--c:${v ? VERDICT[v][1] : "#cbd5e1"}" title="${v ? VERDICT[v][2] : "not reviewed"}">${v ? VERDICT[v][0] : ""}</span>
      <span class="rv-lab">${esc(i.label)}</span>${i.status ? `<span class="st st-${i.status}">${i.status === "pass" ? "ok" : i.status === "fail" ? "below norm" : ""}</span>` : ""}
      <span class="muted small">${esc(i.class_label || i.kind.replace("_", " "))}</span></div>`; };
  const vis = rvVisible(), keep = new Set(vis.map((i) => i.id));
  let h = "";
  D.groups.forEach((g) => { const its = g.items.filter((i) => keep.has(i.id)); if (its.length) h += `<details open><summary>${esc(g.label)}</summary>${its.map(row).join("")}</details>`; });
  const cl = D.clearances.filter((i) => keep.has(i.id));
  if (cl.length) {
    const kinds = { plot_clearance: "Plot clearances (site)", equipment_gap: "Gaps between equipment", wall_gap: "Equipment to walls", ceiling_clearance: "Equipment to ceiling" };
    Object.entries(kinds).forEach(([k, lab]) => { const xs = cl.filter((c) => c.kind === k); if (xs.length) h += `<details ${xs.some((x) => x.status === "fail") || xs.length < 12 ? "open" : ""}><summary>${lab} (${xs.length})</summary>${xs.map(row).join("")}</details>`; });
  }
  const segs = rvSegments();
  if (segs.length) {
    const by = {}; segs.forEach((s) => (by[s.cls] = by[s.cls] || []).push(s));
    h += `<div class="rv-sechead">Masks</div>` + Object.entries(by).map(([cls, xs]) => `<details ${RV.layer.startsWith("mask") ? "open" : ""}><summary><span class="sw" style="background:${maskColor(cls)}"></span>${esc(cls)} (${xs.length})</summary>${xs.map((s) => { const id = "seg:" + s.id, v = verdictOf(id);
      return `<div class="rv-row ${RV.sel === id ? "sel" : ""}" data-id="${esc(id)}"><span class="vd" style="--c:${v ? VERDICT[v][1] : "#cbd5e1"}">${v ? VERDICT[v][0] : ""}</span>
        <span class="rv-lab" style="white-space:nowrap;flex:none">${esc(s.label || s.id)}</span><span class="muted small">${esc(s.source || "")}${s.confidence != null ? " · " + s.confidence : ""}${s.legend ? " · " + esc(s.legend) : ""}</span></div>`; }).join("")}</details>`).join("");
  }
  RV.shown = vis.map((i) => i.id).concat(segs.map((s) => "seg:" + s.id));
  $("#rv-list").innerHTML = (h || '<div class="muted">Nothing matches this layer / filter.</div>') +
    `<div class="muted small rv-key">${RV.shown.length} listed. Dot colour = verdict: <span class="vd" style="--c:#16a34a">✓</span> correct <span class="vd" style="--c:#dc2626">✗</span> wrong <span class="vd" style="--c:#d97706">?</span> unsure</div>`;
  $$("#rv-list .rv-row").forEach((r) => r.addEventListener("click", () => selectReview(r.dataset.id)));
}
function drawReview() {
  const D = RV.data; if (!D) return;
  const pg = D.pages.find((p) => p.page === RV.page);
  if (!pg || !pg.w) { $("#rv-view").innerHTML = '<div class="muted">No page image or size for this drawing.</div>'; return; }
  const padU = pg.w * 0.004, pts = (poly) => poly.map((p) => p.join(",")).join(" ");
  const vis = rvVisible(), keep = new Set(vis.map((i) => i.id));
  let svg = "";
  rvSegments().filter((s) => s.page === RV.page && RV.sel !== "seg:" + s.id).forEach((s) => {
    const c = maskColor(s.cls), v = verdictOf("seg:" + s.id);
    const stroke = v ? VERDICT[v][1] : c;
    svg += s.polygon && s.polygon.length >= 3
      ? `<polygon class="seg" data-seg="${esc(s.id)}" points="${pts(s.polygon)}" fill="${c}" fill-opacity=".30" stroke="${stroke}" stroke-width="${v ? 2.5 : 1.5}"><title>${esc(s.cls)}${s.label ? " · " + esc(s.label) : ""} · ${esc(s.source || "")}${s.legend ? " · legend: " + esc(s.legend) : ""}</title></polygon>`
      : s.polyline ? `<polyline class="seg" data-seg="${esc(s.id)}" points="${pts(s.polyline)}" fill="none" stroke="${stroke}" stroke-width="2.5"/>` : "";
  });
  const boxItems = D.groups.flatMap((g) => g.items).filter((i) => keep.has(i.id) && i.loc.page === RV.page && i.loc.box && i.loc.precision === "exact" && i.id !== RV.sel);
  boxItems.forEach((i) => {
    const [x0, y0, x1, y1] = i.loc.box, v = verdictOf(i.id), col = v ? VERDICT[v][1] : "#2563eb";
    svg += `<rect class="ibox" data-item="${esc(i.id)}" x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" fill="${col}" fill-opacity=".10" stroke="${col}" stroke-opacity=".9" stroke-width="${v ? 2.5 : 1.5}"><title>${esc(i.label)}</title></rect>`;
    if (RV.layer === "equipment") svg += `<text x="${x0}" y="${Math.max(0, y0 - padU * 2)}" style="font-size:${pg.w * 0.0075}px;fill:${col};stroke:#fff;stroke-width:${pg.w * 0.002}px;paint-order:stroke">${esc(String(i.label).split("\n")[0].slice(0, 22))}</text>`;
  });
  // clearances: a line between the two things, coloured by verdict against the rule, labelled in mm
  const shapeC = (l) => [(l.box[0] + l.box[2]) / 2, (l.box[1] + l.box[3]) / 2];
  D.clearances.filter((c) => keep.has(c.id) && c.id !== RV.sel).forEach((c) => {
    const ss = (c.shapes || []).filter((l) => l.page === RV.page && l.box);
    if (ss.length < 2) return;
    const [a, b] = [shapeC(ss[0]), shapeC(ss[1])], col = c.status === "fail" ? "#dc2626" : c.status === "pass" ? "#16a34a" : "#64748b";
    const mm = (c.values.find((v) => v.name === "measured_mm") || c.values.find((v) => v.name === "drawn_mm") || c.values[0] || {}).summary;
    svg += `<line class="cl" data-item="${esc(c.id)}" x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="${col}" stroke-width="2" stroke-dasharray="7 4"/>`;
    if (RV.layer === "clearances") svg += `<text x="${(a[0] + b[0]) / 2}" y="${(a[1] + b[1]) / 2}" style="font-size:${pg.w * 0.0075}px;fill:${col};stroke:#fff;stroke-width:${pg.w * 0.002}px;paint-order:stroke">${esc(mm || "")}</text>`;
  });
  const sel = rvSelected();
  if (sel) {
    const shapes = sel.shapes || [sel.loc];
    const col0 = (verdictOf(sel.id) && VERDICT[verdictOf(sel.id)][1]) || "#e11d48";
    shapes.filter((l) => l.page === RV.page && l.box).forEach((l) => {
      const [x0, y0, x1, y1] = l.box, pad = padU;
      const col = l.role === "feature" ? "#ea580c" : col0;
      if (l.precision === "layout") svg += `<rect x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" fill="#facc15" fill-opacity=".10" stroke="#ca8a04" stroke-width="2.5" stroke-dasharray="8 4"/>`;
      else {
        if (l.polygon && l.polygon.length >= 3) svg += `<polygon points="${pts(l.polygon)}" fill="${col}" fill-opacity=".22" stroke="${col}" stroke-width="2.5"/>`;
        svg += `<rect x="${x0 - pad}" y="${y0 - pad}" width="${x1 - x0 + 2 * pad}" height="${y1 - y0 + 2 * pad}" fill="none" stroke="${col}" stroke-width="3.5"/>`;
      }
    });
    if (shapes.length > 1) {
      const c = shapes.filter((l) => l.box && l.page === RV.page).map(shapeC);
      if (c.length >= 2) svg += `<line x1="${c[0][0]}" y1="${c[0][1]}" x2="${c[1][0]}" y2="${c[1][1]}" stroke="${col0}" stroke-width="3" stroke-dasharray="6 4"/>`;
    }
  }
  $("#rv-view").innerHTML = `<div class="rv-stage" style="width:${RV.zoom * 100}%"><img src="/api/documents/${D.doc_id}/page/${RV.page}.jpg" alt="original drawing">
    <svg viewBox="0 0 ${pg.w} ${pg.h}" preserveAspectRatio="none">${svg}</svg></div>`;
  $$("#rv-view .ibox, #rv-view .cl").forEach((r) => r.addEventListener("click", () => selectReview(r.dataset.item)));
  $$("#rv-view .seg").forEach((r) => r.addEventListener("click", () => {
    const sg = D.segments.find((x) => x.id === r.dataset.seg);
    selectReview(sg && sg.item_id ? sg.item_id : "seg:" + r.dataset.seg);
  }));
  const maskKey = RV.layer === "all" || RV.layer === "masks" || RV.layer.startsWith("mask:") ? [...new Set(rvSegments().filter((s) => s.page === RV.page).map((s) => s.cls))] : [];
  $("#rv-legend").innerHTML = maskKey.map((c) => `<span class="mk" style="--c:${maskColor(c)}">${esc(c)}</span>`).join("") + `<span class="muted"> outline colour on a shape = your verdict (green correct, red wrong, amber unsure)</span>`;
  if (sel && RV.scrollTo) { RV.scrollTo = false; zoomToSelected(pg); }
}
function rvSelected() {
  if (!RV.sel) return null;
  if (RV.sel.startsWith("seg:")) {
    const sg = RV.data.segments.find((s) => s.id === RV.sel.slice(4));
    return sg ? { id: RV.sel, label: `mask · ${sg.cls}`, kind: "mask", segment: sg, loc: { page: sg.page, box: bboxOf(sg.polygon || sg.polyline), precision: "exact", polygon: sg.polygon }, values: [] } : null;
  }
  return rvAll().find((i) => i.id === RV.sel) || null;
}
const bboxOf = (poly) => { const xs = (poly || []).map((p) => p[0]), ys = (poly || []).map((p) => p[1]); return xs.length ? [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)] : null; };
function zoomToSelected(pg) {
  const sel = rvSelected(), box = sel && sel.loc && sel.loc.box;
  const view = $("#rv-view"), stage = $(".rv-stage", view);
  if (!box || !stage) return;
  const bw = Math.max(box[2] - box[0], pg.w * .04), bh = Math.max(box[3] - box[1], pg.h * .04);
  RV.zoom = Math.max(1, Math.min(6, Math.min(pg.w / (bw * 3.2), pg.h / (bh * 3.2))));
  stage.style.width = RV.zoom * 100 + "%";
  const k = stage.clientWidth / pg.w;
  view.scrollLeft = ((box[0] + box[2]) / 2) * k - view.clientWidth / 2;
  view.scrollTop = ((box[1] + box[3]) / 2) * k - view.clientHeight / 2;
}
function selectReview(id) {
  RV.sel = id;
  const it = rvSelected();
  if (it && it.loc && it.loc.page && it.loc.page !== RV.page && RV.data.pages.some((p) => p.page === it.loc.page)) { RV.page = it.loc.page; $("#rv-page").value = RV.page; }
  RV.scrollTo = true;
  renderReviewList(); drawReview(); renderDetail();
  const row = $(`#rv-list .rv-row[data-id="${CSS.escape(id)}"]`); if (row) row.scrollIntoView({ block: "nearest" });
}
async function setVerdict(id, verdict, note) {
  const old = RV.marks[id] || {};
  const nt = note !== undefined ? note : old.note || "";
  try {
    const r = await postJSON(`/api/documents/${RV.data.doc_id}/review-marks/${encodeURIComponent(id)}`, { verdict: verdict || null, note: nt }, "PUT");
    RV.marks = r.marks;
  } catch (e) { alert("Could not save the verdict: " + e.message); return; }
  renderProgress(); renderReviewList(); drawReview(); renderDetail(true);
}
function stepReview(d) {
  if (!RV.shown.length) return;
  const i = RV.shown.indexOf(RV.sel);
  selectReview(RV.shown[(i < 0 ? (d > 0 ? 0 : RV.shown.length - 1) : (i + d + RV.shown.length) % RV.shown.length)]);
}
function renderDetail(keepNote) {
  const it = rvSelected(), el = $("#rv-detail");
  if (!it) { el.innerHTML = '<span class="muted">Click an item, a clearance or a mask. Keys: <b>J</b>/<b>K</b> next/previous, <b>C</b> correct, <b>W</b> wrong, <b>U</b> unsure.</span>'; return; }
  const l = it.loc || {}, mk = RV.marks[it.id] || {};
  const where = it.kind === "mask" ? `mask polygon on page ${l.page}` : l.box ? `page ${l.page}${l.layout_id ? `, layout ${esc(l.layout_id)}` : ""}` : "";
  $("#rv-where").textContent = l.box ? `${it.label}: ${PRECISION_TXT[l.precision]} · ${where}` : `${it.label}: no location recorded`;
  const vals = it.kind === "mask"
    ? [{ name: "mask", type: "mask", unit: "px", summary: `class ${it.segment.cls}, source ${it.segment.source || "?"}${it.segment.confidence != null ? ", confidence " + it.segment.confidence : ""}`, help: TYPES_HELP.mask },
       ...(it.segment.legend ? [{ name: "legend", type: "string", summary: it.segment.legend, help: "Legend line whose colour produced this mask." }] : [])]
    : it.values;
  const shapes = (it.shapes || []).length ? `<div class="small muted">Drawn on the page: ${it.shapes.map((s) => esc(s.role || "")).join(", ")}</div>` : "";
  el.innerHTML = `<div class="row"><h3 style="margin:0">${esc(it.label)}</h3>${it.class ? `<span class="muted small">${esc(it.class_label || it.class)}</span>` : ""}${it.status ? `<span class="st st-${it.status}">${it.status === "pass" ? "meets norm" : it.status === "fail" ? "below norm" : ""}</span>` : ""}</div>
    <div class="vbar"><button class="btn vb ${mk.verdict === "correct" ? "on ok" : ""}" data-v="correct">✓ Correct</button><button class="btn vb ${mk.verdict === "wrong" ? "on bad" : ""}" data-v="wrong">✗ Wrong</button><button class="btn vb ${mk.verdict === "unsure" ? "on warnv" : ""}" data-v="unsure">? Unsure</button>
      <span class="spacer"></span><button class="btn small" id="rv-prev" title="K">◀</button><button class="btn small" id="rv-next" title="J">▶</button></div>
    <textarea id="rv-note" rows="2" placeholder="Note: what is wrong, or what it should be…">${esc(mk.note || "")}</textarea>
    <div class="small ${l.precision === "layout" || !l.box ? "warn" : "muted"}">${esc(PRECISION_TXT[l.precision] || "")}${l.why ? " — " + esc(l.why) : ""}</div>${shapes}
    <table class="ft"><tr><th>value</th><th>extracted</th><th>type</th></tr>${vals.map((v) => `<tr><td><code>${esc(v.name)}</code>${v.help ? `<div class="muted small">${esc(v.help)}</div>` : ""}</td>
      <td>${esc(v.summary)}${v.note ? `<div class="muted small">${esc(v.note)}</div>` : ""}</td><td>${typeBadge(v.type, RV.data.types)}${v.unit ? `<div class="muted small">${esc(v.unit)}</div>` : ""}</td></tr>`).join("")}</table>`;
  $$("#rv-detail .vb").forEach((b) => b.addEventListener("click", () => setVerdict(it.id, mk.verdict === b.dataset.v ? null : b.dataset.v)));
  $("#rv-note").addEventListener("change", (e) => setVerdict(it.id, mk.verdict || null, e.target.value));
  $("#rv-prev").addEventListener("click", () => stepReview(-1));
  $("#rv-next").addEventListener("click", () => stepReview(1));
}
function reviewCSV() {
  const D = RV.data, q = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const rows = [["kind", "id", "label", "class", "verdict", "note", "page", "values"]];
  rvAll().forEach((i) => rows.push([i.kind, i.id, i.label, i.class_label || i.class || "", verdictOf(i.id), (RV.marks[i.id] || {}).note || "", (i.loc || {}).page || "",
    (i.values || []).map((v) => `${v.name}=${v.summary}`).join("; ")]));
  D.segments.forEach((s) => rows.push(["mask", "seg:" + s.id, s.label || s.id, s.cls, verdictOf("seg:" + s.id), (RV.marks["seg:" + s.id] || {}).note || "", s.page, `source=${s.source || ""}; confidence=${s.confidence ?? ""}; legend=${s.legend || ""}`]));
  saveBlob(new Blob(["﻿" + rows.map((r) => r.map(q).join(",")).join("\r\n")], { type: "text/csv;charset=utf-8" }), `review_${D.file_name.replace(/\.[^.]+$/, "").replace(/[^\w.-]+/g, "_")}.csv`);
}
$("#rv-doc").addEventListener("change", (e) => loadReview(e.target.value));
$("#rv-page").addEventListener("change", (e) => { RV.page = +e.target.value; drawReview(); });
$("#rv-layer").addEventListener("change", (e) => { RV.layer = e.target.value; RV.sel = null; renderReview(); renderDetail(); });
$("#rv-vfilter").addEventListener("change", (e) => { RV.vfilter = e.target.value; renderReview(); });
$("#rv-filter").addEventListener("input", () => RV.data && renderReview());
$("#rv-zin").addEventListener("click", () => { RV.zoom = Math.min(8, RV.zoom * 1.4); drawReview(); });
$("#rv-zout").addEventListener("click", () => { RV.zoom = Math.max(1, RV.zoom / 1.4); drawReview(); });
$("#rv-fit").addEventListener("click", () => { RV.zoom = 1; drawReview(); });
$("#rv-csv").addEventListener("click", () => RV.data && reviewCSV());
$("#rv-allok").addEventListener("click", async () => {
  if (!RV.data) return;
  const ids = rvVisible().map((i) => i.id).filter((id) => !verdictOf(id));
  if (!ids.length || !confirm(`Mark ${ids.length} listed item(s) as correct?`)) return;
  RV.marks = (await postJSON(`/api/documents/${RV.data.doc_id}/review-marks`, { item_ids: ids, verdict: "correct" }, "PUT")).marks;
  renderReview(); renderDetail();
});
document.addEventListener("keydown", (e) => {
  if (!$("#tab-review").classList.contains("active") || !RV.data || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === "j") { e.preventDefault(); stepReview(1); } else if (k === "k") { e.preventDefault(); stepReview(-1); }
  else if (RV.sel && ["c", "w", "u"].includes(k)) { e.preventDefault(); const v = { c: "correct", w: "wrong", u: "unsure" }[k]; setVerdict(RV.sel, verdictOf(RV.sel) === v ? null : v); }
});
/* open the Review tab on a given drawing and item (used by the Site page) */
async function openInReview(docId, itemId) {
  showTab("review");
  if (!DOCS.length) DOCS = await api("/api/documents");
  if (!RV.data || RV.data.doc_id !== docId) { $("#rv-doc").innerHTML = DOCS.map((d) => `<option value="${d.doc_id}">${esc(d.file_name)}</option>`).join(""); await loadReview(docId); }
  if (itemId) selectReview(itemId);
}

async function loadAdmin() {
  const [h, f, v, s] = await Promise.all([api("/api/health"), api("/api/engines"), api("/api/versions"), api("/api/settings")]);
  $("#kg-on").checked = f.kg_enabled; $("#rag-on").checked = f.rag_enabled; $("#admin-mode").value = f.retrieval_mode;
  $("#health").textContent = JSON.stringify(h, null, 1);
  $("#settings").textContent = JSON.stringify(s, null, 1);
  $("#versions").innerHTML = `<table><tr><th class="num">v</th><th>created</th><th>note</th><th class="num">docs</th></tr>` +
    v.map((x) => `<tr><td class="num">${x.version}</td><td class="small">${esc(x.created_at)}</td><td>${esc(x.note)}</td><td class="num">${x.n_docs}</td></tr>`).join("") + "</table>";
}
$("#save-engines").addEventListener("click", async () => {
  await postJSON("/api/engines", { retrieval_mode: $("#admin-mode").value, kg_enabled: $("#kg-on").checked, rag_enabled: $("#rag-on").checked }, "PUT");
  loadAdmin(); refreshStatus();
});

refreshStatus();
setInterval(refreshStatus, 15000);


/* ---------------------------------------------------------------- rules */
let RULES = null;
const fmtVal = (v) => (v == null || v === "" ? "" : typeof v === "number" ? v.toLocaleString() : String(v));
const RS = { sec: null, grp: "", sel: null, flt: "" };
async function loadRules() {
  const err = $("#rule-err");
  try { RULES = await api("/api/rules"); err.classList.add("hidden"); }
  catch (e) { err.classList.remove("hidden"); err.textContent = `Could not load the rules (${e.message}). If the server was started before this version, restart it (sr serve) and reload the page.`; return; }
  if (!RS.sec || !RULES.sections.some((s) => s.id === RS.sec)) RS.sec = RULES.sections[0] && RULES.sections[0].id;
  renderRules();
}
$$("#rule-chips .chip").forEach((c) => c.addEventListener("click", () => { RS.flt = c.dataset.f; $$("#rule-chips .chip").forEach((x) => x.classList.toggle("on", x === c)); RS.grp = ""; RULES && renderRules(); }));
const isTodo = (r) => /confirm/i.test(r.ref_status || "");
function ruleHit(r) {
  const q = $("#rule-q").value.trim().toLowerCase(), who = $("#rule-who").value;
  if (who && /^(CSS|DSS)$/.test(r.applies_to || "") && r.applies_to !== who) return false;
  if (RS.flt === "todo" && !isTodo(r)) return false;
  if (RS.flt === "edited" && !(r.origin === "user" || r.origin === "edited")) return false;
  if (RS.flt === "enf" && !r.enforce) return false;
  return !q || [r.title, r.text, fmtVal(r.value), r.reference, r.source, r.group, r.rule_no, JSON.stringify(r.values || "")].join(" ").toLowerCase().includes(q);
}
function renderRules() {
  const q = $("#rule-q").value.trim();
  const hits = RULES.rules.filter(ruleHit);
  const bySec = new Map(RULES.sections.map((s) => [s.id, []]));
  hits.forEach((r) => (bySec.get(r.section) || bySec.set(r.section, []).get(r.section)).push(r));
  $("#rule-meta").textContent = `${hits.length} of ${RULES.rules.length} rules${RULES.edited ? " · edited copy in use (Reset returns to the extracted rules)" : " · as extracted"}`;
  // while searching, jump to the first section that has a hit
  if ((q || RS.flt) && !(bySec.get(RS.sec) || []).length) { const f = RULES.sections.find((s) => bySec.get(s.id).length); if (f) { RS.sec = f.id; RS.grp = ""; } }
  // left: section → group tree
  $("#rule-nav").innerHTML = RULES.sections.map((s) => {
    const rs = bySec.get(s.id) || [], act = s.id === RS.sec;
    const groups = new Map(); rs.forEach((r) => groups.set(r.group || "", (groups.get(r.group || "") || 0) + 1));
    const sub = act && groups.size > 1 ? `<div class="rsub">${[...groups.entries()].map(([g, n]) => `<a data-s="${s.id}" data-g="${esc(g)}" class="${RS.grp === g ? "on" : ""}">${esc(g || "General")} <span class="muted">${n}</span></a>`).join("")}</div>` : "";
    return `<a data-s="${s.id}" data-g="" class="rsecl ${act && !RS.grp ? "on" : act ? "open" : ""} ${rs.length ? "" : "dim"}">${esc(s.title)} <span class="muted">${rs.length}</span></a>${sub}`;
  }).join("");
  $$("#rule-nav a").forEach((a) => a.addEventListener("click", () => { RS.sec = a.dataset.s; RS.grp = a.dataset.g; renderRules(); }));
  // middle: rules of the chosen section/group
  const sec = RULES.sections.find((s) => s.id === RS.sec) || {};
  let rs = (bySec.get(RS.sec) || []);
  if (RS.grp) rs = rs.filter((r) => (r.group || "") === RS.grp);
  const groups = new Map(); rs.forEach((r) => (groups.get(r.group || "") || groups.set(r.group || "", []).get(r.group || "")).push(r));
  const head = `<div class="row"><h3 style="margin:0">${esc(sec.title || "")}</h3><span class="muted small">${rs.length} rule(s)</span><span class="spacer"></span><button class="btn small radd">+ Add to this section</button></div>${sec.about ? `<div class="muted small" style="margin:2px 0 8px">${esc(sec.about)}</div>` : ""}`;
  const body = [...groups.entries()].map(([g, items]) => `${g && !RS.grp ? `<div class="rgh">${esc(g)}</div>` : ""}${ruleTable(items)}`).join("");
  $("#rule-list").innerHTML = head + (body || '<div class="muted small" style="padding:12px 0">No rules match here.</div>');
  $$("#rule-list .rrow").forEach((tr) => tr.addEventListener("click", () => { RS.sel = tr.dataset.id; renderRules(); }));
  $$("#rule-list .radd").forEach((b) => b.addEventListener("click", () => editRule(null, RS.sec)));
  renderRuleDetail();
}
function ruleTable(items) {
  // rules that carry named values (clearances, dimensions) share one compact table; others are one line each
  const names = [...new Set(items.flatMap((r) => (r.values ? Object.keys(r.values) : [])))].slice(0, 6);
  const isNum = (r) => typeof r.value === "number" || (typeof r.value === "string" && /^-?\d+(\.\d+)?$/.test(r.value));
  const anyNum = items.some(isNum);
  const cell = (r) => (isNum(r) ? `<b>${esc(fmtVal(r.value))}</b> <span class="muted">${esc(r.unit || "")}</span>` : "");
  const sub = (r) => (r.value != null && r.value !== "" && !isNum(r) ? `<div class="small muted rsubv">${esc(fmtVal(r.value))}</div>` : "");
  const flags = (r) => `${isTodo(r) ? '<span class="rstat todo" title="Reference to be confirmed">confirm</span>' : ""}${r.origin === "user" ? '<span class="tag">added</span>' : r.origin === "edited" ? '<span class="tag">edited</span>' : ""}${r.enforce ? '<span class="rstat ok" title="Drives a live check">check</span>' : ""}`;
  return `<table class="rt"><tr><th>#</th><th>Rule</th>${names.map((n) => `<th class="num">${esc(n)}</th>`).join("")}${anyNum ? '<th class="num">Value</th>' : ""}<th></th></tr>${items.map((r) =>
    `<tr class="rrow ${r.id === RS.sel ? "sel" : ""}" data-id="${esc(r.id)}"><td class="rno">${esc(r.rule_no || "")}</td><td class="rtt">${esc(r.title)}${sub(r)}</td>${names.map((n) => `<td class="num">${r.values && r.values[n] != null ? esc(fmtVal(r.values[n])) : ""}</td>`).join("")}${anyNum ? `<td class="num">${cell(r)}</td>` : ""}<td>${flags(r)}</td></tr>`).join("")}</table>`;
}
function renderRuleDetail() {
  const el = $("#rule-detail"), r = RULES.rules.find((x) => x.id === RS.sel);
  if (!r) { el.innerHTML = '<span class="muted">Pick a rule to see its full text, reference and source.</span>'; return; }
  const vals = r.values ? Object.entries(r.values).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="num"><b>${esc(fmtVal(v))}</b> <span class="muted">${esc(r.unit || "")}</span></td></tr>`).join("") : "";
  el.innerHTML = `<div class="muted small">${esc((RULES.sections.find((s) => s.id === r.section) || {}).title || "")}${r.group ? " › " + esc(r.group) : ""}${r.rule_no ? " · #" + esc(r.rule_no) : ""}</div>
    <h3 style="margin:4px 0 6px">${esc(r.title)}</h3>
    ${r.value != null && r.value !== "" ? `<div class="bigv">${esc(fmtVal(r.value))} <span class="muted">${esc(r.unit || "")}</span></div>` : ""}
    ${vals ? `<table class="ft">${vals}</table>` : ""}
    ${r.text ? `<p class="small">${esc(r.text)}</p>` : ""}
    ${r.reference ? `<div class="small"><b>Reference</b><br>${esc(r.reference)} ${r.ref_status ? `<span class="rstat ${isTodo(r) ? "todo" : "ok"}">${esc(isTodo(r) ? "to confirm" : r.ref_status)}</span>` : ""}</div>` : ""}
    <div class="small muted" style="margin-top:6px">Applies to ${esc(r.applies_to || "–")} · ${esc(r.source || "")}${r.enforce ? ` · <span class="enf">drives ${esc(r.enforce)}</span>` : ""}</div>
    <div class="row" style="margin-top:10px"><button class="btn primary redit">Edit</button><button class="btn rdup">Duplicate</button><span class="spacer"></span><button class="btn rdel">Delete</button></div>`;
  $("#rule-detail .redit").addEventListener("click", () => editRule(r.id));
  $("#rule-detail .rdel").addEventListener("click", () => delRule(r.id));
  $("#rule-detail .rdup").addEventListener("click", () => editRule(null, r.section, r));
}
const parseVal = (t) => { t = t.trim(); return t === "" ? null : /^-?\d+(\.\d+)?$/.test(t) ? Number(t) : t; };
function editRule(id, section, copyOf) {
  const r = id ? RULES.rules.find((x) => x.id === id) : copyOf ? { ...copyOf, title: copyOf.title + " (copy)", enforce: null } : { section: section || RULES.sections[0].id, applies_to: "CSS+DSS", values: null };
  const f = $("#rule-form");
  const vals = r.values ? Object.entries(r.values).map(([k, v]) => `${k}: ${v}`).join("\n") : "";
  f.innerHTML = `<h3>${id ? "Edit rule" : "Add rule"}</h3>
    <label>Section<select name="section">${RULES.sections.map((s) => `<option value="${s.id}" ${s.id === r.section ? "selected" : ""}>${esc(s.title)}</option>`).join("")}</select></label>
    <label>Rule<input name="title" value="${esc(r.title || "")}" required></label>
    <label>Detail<textarea name="text" rows="3">${esc(r.text || "")}</textarea></label>
    <div class="two"><label>Value<input name="value" value="${esc(r.value ?? "")}" placeholder="number or text"></label>
      <label>Unit<input name="unit" value="${esc(r.unit || "")}" placeholder="mm, m, %"></label></div>
    <label>Values by name (one per line, e.g. <code>front: 1000</code>)<textarea name="values" rows="3">${esc(vals)}</textarea></label>
    <div class="two"><label>Applies to<input name="applies_to" value="${esc(r.applies_to || "")}"></label>
      <label>Group<input name="group" value="${esc(r.group || "")}"></label></div>
    <label>Reference (regulation / clause)<textarea name="reference" rows="2">${esc(r.reference || "")}</textarea></label>
    <div class="two"><label>Reference status<input name="ref_status" value="${esc(r.ref_status || "")}" placeholder="e.g. confirmed against DCPR text"></label>
      <label>Rule no.<input name="rule_no" value="${esc(r.rule_no || "")}"></label></div>
    <label>Source<input name="source" value="${esc(r.source || "")}"></label>
    ${r.enforce ? `<div class="small muted">This value drives <code>${esc(r.enforce)}</code> in the live checks.</div>` : ""}
    <div class="row"><span class="spacer"></span><button type="button" class="btn" id="rule-cancel">Cancel</button><button class="btn primary" id="rule-save" value="save">Save</button></div>`;
  $("#rule-cancel").addEventListener("click", () => $("#rule-dlg").close());
  $("#rule-save").addEventListener("click", async (ev) => {
    ev.preventDefault();
    if (!f.reportValidity()) return;
    const g = (n) => f.elements[n].value;
    const values = {};
    g("values").split("\n").forEach((ln) => { const m = ln.match(/^\s*([^:]+):\s*(.+)$/); if (m) values[m[1].trim()] = parseVal(m[2]); });
    const body = { section: g("section"), title: g("title").trim(), text: g("text"), value: parseVal(g("value")), unit: g("unit") || null,
      values: Object.keys(values).length ? values : null, applies_to: g("applies_to") || "CSS+DSS", group: g("group") || null, reference: g("reference"),
      ref_status: g("ref_status"), rule_no: g("rule_no") || null, source: g("source") };
    try { id ? await postJSON(`/api/rules/${encodeURIComponent(id)}`, body, "PUT") : await postJSON("/api/rules", body); $("#rule-dlg").close(); await loadRules(); }
    catch (e) { alert(e.message); }
  });
  $("#rule-dlg").showModal();
}
async function delRule(id) {
  const r = RULES.rules.find((x) => x.id === id);
  if (!confirm(`Delete this rule?\n\n${r.title}`)) return;
  try { await api(`/api/rules/${encodeURIComponent(id)}`, { method: "DELETE" }); await loadRules(); } catch (e) { alert(e.message); }
}
$("#rule-q").addEventListener("input", () => RULES && renderRules());
$("#rule-who").addEventListener("change", () => RULES && renderRules());
$("#rule-add").addEventListener("click", () => RULES && editRule(null));
$("#rule-reset").addEventListener("click", async () => { if (confirm("Discard all rule edits and go back to the extracted rules?")) { await postJSON("/api/rules/reset", {}); await loadRules(); } });
