"""Segmentation refine: LLM boxes -> mask polygons.

Seeds are the class boxes from pass 2. Each seed is refined with
  1. legend colour: pixels matching the legend swatch colour of that class (HSV), connected components
     overlapping the seed become the mask;
  2. PDF vector paths: closed, filled paths of that colour inside the seed are taken verbatim (exact);
  3. otherwise the seed box itself (confidence 0.5).
Classes without seeds but with a legend colour (trench, wayleave, site boundary, ...) are taken from the
colour mask directly when the components are large enough. Returns polygons in page px + debug masks.
"""
from __future__ import annotations

import numpy as np

try:
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

HSV = {
    "red": [((0, 90, 90), (10, 255, 255)), ((170, 90, 90), (179, 255, 255))],
    "magenta": [((140, 80, 80), (169, 255, 255))], "pink": [((140, 40, 120), (175, 255, 255))],
    "yellow": [((20, 90, 120), (35, 255, 255))], "green": [((40, 80, 60), (85, 255, 255))],
    "cyan": [((85, 80, 80), (100, 255, 255))], "blue": [((100, 80, 60), (130, 255, 255))],
    "orange": [((10, 100, 120), (20, 255, 255))], "brown": [((5, 80, 40), (20, 255, 160))],
}
SEMANTIC_TO_CLASS = {"site_boundary": "site_boundary", "substation_boundary": "site_boundary", "access_path": "access_path",
                     "wayleave": "wayleave", "trench": "trench", "cable_tray": "cable_tray", "cutout": "cutout", "beam": "beam",
                     "column": "column", "ms_plate": "platform", "nalla": "nalla", "road": "dp_road", "tree": "tree"}
NAMED_RGB = {"red": (230, 30, 30), "magenta": (220, 0, 220), "yellow": (240, 220, 0), "green": (0, 170, 0), "blue": (0, 60, 230),
             "cyan": (0, 200, 220), "orange": (250, 140, 0), "brown": (150, 80, 20), "pink": (240, 120, 200)}


# What each class usually looks like, learned from the legends of already-parsed drawings (scripts/learn_palette.py ->
# config/learned_palette.json). Used ONLY for a class the drawing's own legend does not cover. Fallback when that file
# is absent: the most frequent colour per class in those legends.
DEFAULT_PALETTE = {"site_boundary": [((255, 0, 0), 0.57)], "access_path": [((255, 255, 0), 0.83)], "trench": [((0, 0, 255), 0.75)],
                   "cutout": [((255, 0, 255), 0.67)], "beam": [((0, 255, 0), 0.67)]}


def learned_prior(data: dict | None, min_share: float = 0.4) -> dict[str, list[tuple]]:
    """learned_palette.json -> {class: [(rgb, share)]}. A colour that several segmentable classes use goes to the class
    whose drawings use it most often; colours used by fewer than `min_share` of a class's drawings are dropped."""
    if not data:
        return DEFAULT_PALETTE
    cands = []                                              # (cls, rgb, share)
    for sem, v in data.items():
        cls = SEMANTIC_TO_CLASS.get(sem)
        if not cls:
            continue
        for c in v.get("colours") or []:
            cands.append((cls, tuple(c["rgb"]), float(c["share"])))
    out: dict[str, list[tuple]] = {}
    for cls, rgb, sh in cands:
        if sh < min_share:
            continue
        rivals = [x for x in cands if x[0] != cls and sum(abs(a - b) for a, b in zip(x[1], rgb)) <= 60 and x[2] > sh]
        if rivals:
            continue
        out.setdefault(cls, []).append((rgb, sh))
    return out


def colour_mask(rgb: np.ndarray, colour: str) -> np.ndarray | None:
    if cv2 is None or colour not in HSV:
        return None
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    m = np.zeros(rgb.shape[:2], np.uint8)
    for lo, hi in HSV[colour]:
        m |= cv2.inRange(hsv, np.array(lo), np.array(hi))
    return m


def rgb_mask(rgb: np.ndarray, target, tol: float = 22.0) -> np.ndarray | None:
    """Pixels within `tol` (CIELAB distance) of the swatch colour sampled from the drawing's own legend."""
    if cv2 is None or target is None:
        return None
    lab = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    t = cv2.cvtColor(np.array([[target]], np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)[0, 0]
    # OpenCV 8-bit Lab: L scaled 0..255, a/b offset by 128; compare in those units, L weighted down (shading varies)
    d = np.sqrt(0.5 * (lab[..., 0] - t[0]) ** 2 + (lab[..., 1] - t[1]) ** 2 + (lab[..., 2] - t[2]) ** 2)
    return (d <= tol).astype(np.uint8) * 255


def swatch_rgb(img: np.ndarray, box_px) -> tuple[int, int, int] | None:
    """Dominant non-white, non-black colour inside a legend swatch box (median of the saturated pixels)."""
    try:
        x0, y0, x1, y1 = (int(round(v)) for v in box_px[:4])
    except Exception:
        return None
    H, W = img.shape[:2]
    x0, x1 = max(0, min(x0, x1)), min(W, max(x0, x1))
    y0, y1 = max(0, min(y0, y1)), min(H, max(y0, y1))
    if x1 - x0 < 2 or y1 - y0 < 2:
        return None
    px = img[y0:y1, x0:x1].reshape(-1, 3).astype(int)
    mx, mn = px.max(1), px.min(1)
    keep = (mx - mn >= 40) & (mx > 60)          # coloured pixels only; white paper, black linework and grey drop out
    if keep.sum() < 4:
        return None
    return tuple(int(v) for v in np.median(px[keep], axis=0))


def _polys(mask: np.ndarray, min_area: float) -> list[np.ndarray]:
    k = np.ones((3, 3), np.uint8)
    m = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    for c in cnts:
        if cv2.contourArea(c) < min_area:
            continue
        out.append(cv2.approxPolyDP(c, 0.004 * cv2.arcLength(c, True), True)[:, 0, :].astype(float))
    return out


MIN_SIDE_PX = 14.0     # at the 200 dpi page render: letters and hairlines are thinner than any drawn tray, plate or boundary


def _thick(poly: np.ndarray, min_side: float = MIN_SIDE_PX) -> bool:
    (_, _), (w, h), _ = cv2.minAreaRect(poly.astype(np.float32))
    return min(w, h) >= min_side


def _overlaps(poly: np.ndarray, box, pad: float) -> bool:
    x0, y0 = poly.min(0)
    x1, y1 = poly.max(0)
    return not (x1 < box[0] - pad or x0 > box[2] + pad or y1 < box[1] - pad or y0 > box[3] + pad)


def _colour_close(rgb, target, tol=60) -> bool:
    return rgb is not None and target is not None and sum(abs(a - b) for a, b in zip(rgb, target)) <= tol * 3


# A legend line says what its colour means. The legend text decides first for the classes people name explicitly
# (cut-out, wayleave, access path, cable tray), because the model's coarse 'semantic' tag often calls trays "trench".
TEXT_FIRST = [("cutout", r"cut\s*-?\s*outs?\b"), ("wayleave", r"way\s*-?\s*leave"),
              ("cable_tray", r"\btrays?\b"), ("access_path", r"\baccess\b|\bstaff\b|\bvehicle")]
TEXT_LATER = [("trench", r"trench|hdpe|duct|pipe"), ("platform", r"ms\s*plate|platform|steel plate"), ("column", r"\bcolumns?\b"),
              ("beam", r"\bbeams?\b"), ("site_boundary", r"css location|substation (boundary|location)|plot boundary|proposed css"),
              ("tree", r"\btrees?\b"), ("nalla", r"nalla|nullah"), ("dp_road", r"\bdp road\b")]


def legend_class(g: dict) -> str | None:
    import re
    t = (g.get("text") or "").lower()
    for cls, rx in TEXT_FIRST:
        if re.search(rx, t):
            return cls
    c = SEMANTIC_TO_CLASS.get((g.get("semantic") or "").lower())
    if c:
        return c
    for cls, rx in TEXT_LATER:
        if re.search(rx, t):
            return cls
    return None


# Which legend classes belong on which kind of layout. A site plan shows the plot, the CSS location and the access;
# trays, platforms, cut-outs and beams are drawn on the room plans. A wayleave drawing also carries the trench legend.
SITE_CLASSES = {"site_boundary", "access_path", "wayleave", "tree", "nalla", "dp_road"}
WAYLEAVE_EXTRA = {"trench", "cable_tray"}
ROOM_CLASSES = {"cable_tray", "trench", "platform", "cutout", "beam", "column"}


def refine(crop: np.ndarray, crop_origin: tuple[float, float], seeds: dict[str, list[list[float]]],
           legend: list[dict], paths: list[dict] | None = None, min_area_frac: float = 0.0002,
           palette: dict[str, list[tuple]] | None = None, allowed: set[str] | None = None,
           text_boxes: list | None = None) -> tuple[list[dict], dict]:
    """seeds: cls -> boxes in page px. Returns (segments [{cls, polygon_px, source, confidence}], masks {cls: uint8}).

    Colours come from the drawing's own legend (every legend line of a class, e.g. HT trench and LT trench), measured on
    the page when the swatch was located, else from the colour name. Only a class the legend does not mention at all falls
    back to the learned colour, and then only where the LLM already put a box.

    allowed: classes that make sense on this kind of layout (site-level classes on a site plan, room-level ones on a
    room plan); legend colours of other classes are ignored there, so green trees on a site plan are not read as trays.
    text_boxes: word boxes of the PDF text layer (page px); coloured text is not a mask."""
    if cv2 is None:
        return [{"cls": c, "polygon_px": _box(b), "source": "llm", "confidence": 0.5} for c, bs in seeds.items() for b in bs], {}
    H, W = crop.shape[:2]
    ox, oy = crop_origin
    min_area = max(min_area_frac * H * W, 150.0)
    text_mask = None
    if text_boxes:
        text_mask = np.zeros((H, W), np.uint8)
        for b in text_boxes:
            x0, y0, x1, y1 = (int(round(v)) for v in b[:4])
            cv2.rectangle(text_mask, (x0 - int(ox) - 1, y0 - int(oy) - 1), (x1 - int(ox) + 1, y1 - int(oy) + 1), 255, -1)
    specs: dict[str, list[dict]] = {}
    covered: set[str] = set()
    for g in legend or []:
        cls = legend_class(g)
        if not cls:
            continue
        covered.add(cls)
        if allowed is not None and cls not in allowed:
            continue
        col = (g.get("color_name") or g.get("color") or "").lower()
        rgb = tuple(int(v) for v in g["rgb"]) if g.get("rgb") and len(g["rgb"]) == 3 else None
        if not rgb and col not in HSV:
            continue                                         # grey / black swatch: cannot be told apart by colour
        sp = {"rgb": rgb, "name": col if col in HSV else None, "text": g.get("text") or "", "prior": False, "conf": 0.85 if rgb else 0.8}
        if not any(x["text"] == sp["text"] and x["rgb"] == rgb and x["name"] == sp["name"] for x in specs.setdefault(cls, [])):
            specs[cls].append(sp)
    taken = [x["rgb"] or NAMED_RGB.get(x["name"]) for v in specs.values() for x in v]
    taken = [t for t in taken if t]
    for cls, cols in (DEFAULT_PALETTE if palette is None else palette).items():
        if cls in covered or not seeds.get(cls) or (allowed is not None and cls not in allowed):
            continue
        ok = [(rgb, sh) for rgb, sh in cols if not any(sum(abs(a - b) for a, b in zip(rgb, t)) <= 110 for t in taken)]
        specs[cls] = [{"rgb": tuple(rgb), "name": None, "text": None, "prior": True, "conf": round(0.45 + 0.3 * sh, 2)} for rgb, sh in ok]
    segs, masks = [], {}
    for cls in set(seeds) | set(specs):
        boxes = seeds.get(cls, [])
        used = [False] * len(boxes)
        for sp in specs.get(cls, []):
            m = rgb_mask(crop, sp["rgb"]) if sp["rgb"] else colour_mask(crop, sp["name"])
            if (m is None or not m.any()) and sp["rgb"] and sp["name"]:
                m = colour_mask(crop, sp["name"])            # swatch colour missed (anti-aliasing): named colour instead
            if m is not None and text_mask is not None:
                m = cv2.bitwise_and(m, cv2.bitwise_not(text_mask))
            if m is not None and m.any():
                masks[cls] = m if cls not in masks else (masks[cls] | m)
                for pl in _polys(m, min_area):
                    pg = pl + [ox, oy]
                    hit = [i for i, b in enumerate(boxes) if _overlaps(pg, b, 0.01 * max(H, W))]
                    if boxes and not hit:
                        continue
                    if not boxes and not _thick(pl):
                        continue
                    for i in hit:
                        used[i] = True
                    segs.append({"cls": cls, "polygon_px": pg.round(1).tolist(), "source": "prior_colour" if sp["prior"] else "legend_colour",
                                 "confidence": sp["conf"], "legend": sp["text"]})
            if not paths:
                continue
            target = sp["rgb"] or NAMED_RGB.get(sp["name"])
            if not target:
                continue
            loose = []                                       # unseeded paths of this colour: merged below, not one segment each
            for pth in paths:
                if not pth.get("closed") or not _colour_close(pth.get("fill"), target):
                    continue
                pts = np.array(pth["pts"])
                if len(pts) < 3:
                    continue
                if not (ox <= pts[:, 0].min() and pts[:, 0].max() <= ox + W and oy <= pts[:, 1].min() and pts[:, 1].max() <= oy + H):
                    continue
                hit = [i for i, b in enumerate(boxes) if _overlaps(pts, b, 2)]
                if boxes and not hit:
                    continue
                if not boxes:
                    loose.append(pts)
                    continue
                for i in hit:
                    used[i] = True
                segs.append({"cls": cls, "polygon_px": pts.round(1).tolist(), "source": "vector",
                             "confidence": 0.7 if sp["prior"] else 0.95, "legend": sp["text"]})
            if loose:
                # hatched / tiled fills are hundreds of small paths: paint them into one mask and take its outlines
                vm = np.zeros((H, W), np.uint8)
                for pts in loose:
                    cv2.fillPoly(vm, [np.round(pts - [ox, oy]).astype(np.int32)], 255)
                k = max(3, int(0.004 * max(H, W)))
                vm = cv2.morphologyEx(vm, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
                for pg in _polys(vm, min_area):
                    if not _thick(pg):
                        continue
                    segs.append({"cls": cls, "polygon_px": (pg + [ox, oy]).round(1).tolist(), "source": "vector",
                                 "confidence": 0.7 if sp["prior"] else 0.9, "legend": sp["text"]})
        for i, b in enumerate(boxes):
            if not used[i]:
                segs.append({"cls": cls, "polygon_px": _box(b), "source": "llm", "confidence": 0.5})
    return segs, masks


def _box(b) -> list[list[float]]:
    x0, y0, x1, y1 = b
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]
