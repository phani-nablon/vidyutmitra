import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(services):
    import substation_retrieval.services as S
    S._SERVICES = services
    from substation_retrieval.api.app import app
    with TestClient(app) as c:
        yield c


def test_ui_and_health(client):
    assert client.get("/").status_code == 200
    h = client.get("/api/health").json()
    assert h["index"]["documents"] >= 4 and "kg" in h["engines"]


def test_chat_search_and_followup(client):
    r = client.post("/api/chat", json={"message": "indoor CSS 2 x 1500 kVA DT, RMU, 2 LTP, room 11 x 8 m"}).json()
    assert r["search"]["results"] and r["search"]["results"][0]["overlay"]["room"]
    f = client.post("/api/chat", json={"message": "why is #2 lower?", "session_id": r["session_id"]}).json()
    assert f["intent"] == "followup"


def test_graph_ontology_and_toggles(client):
    d = client.get("/api/documents").json()[0]["doc_id"]
    g = client.get(f"/api/documents/{d}/graph").json()
    assert any(n["label"] == "substation" for n in g["nodes"])
    assert client.get("/api/ontology").json()["tree"]["id"] == "css"
    assert client.put("/api/engines", json={"retrieval_mode": "rag"}).json()["retrieval_mode"] == "rag"
    assert client.put("/api/engines", json={"retrieval_mode": "auto"}).json()["retrieval_mode"] == "auto"
    assert client.put("/api/engines", json={"retrieval_mode": "bogus"}).status_code == 400


def test_review_payload_and_ontology_info(client):
    d = client.get("/api/documents").json()[0]["doc_id"]
    r = client.get(f"/api/documents/{d}/review").json()
    items = [i for g in r["groups"] for i in g["items"]]
    assert items and r["pages"] and set(r["types"]) >= {"polygon", "mask", "string", "number"}
    eq = next(i for i in items if i["kind"] == "equipment")
    assert {"label", "L_mm"} <= {v["name"] for v in eq["values"]}
    assert all(v["type"] in r["types"] for i in items for v in i["values"])
    assert eq["loc"]["precision"] in ("exact", "segment", "layout", "none")
    assert any(v["type"] == "polygon" for i in items for v in i["values"]) or any(s["polygon"] for s in r["segments"])
    # ontology: each class carries an explanation and typed fields
    def nodes(n):
        yield n
        for c in n["children"]:
            yield from nodes(c)
    onto = client.get("/api/ontology").json()["view"]
    infos = [n["info"] for n in nodes(onto)]
    assert all(i and i["what"] for i in infos)
    tr = next(i for i in infos if i["id"] == "transformer")
    assert {"name": "kva", "type": "integer"}.items() <= next(f for f in tr["fields"] if f["name"] == "kva").items()


def test_rules_crud_and_enforcement(client):
    r = client.get("/api/rules").json()
    assert {s["id"] for s in r["sections"]} >= {"plot", "clearance", "civil", "cable", "process", "kb"}
    assert len(r["rules"]) > 100 and all(x["source"] for x in r["rules"] if x["origin"] == "seed")
    new = client.post("/api/rules", json={"section": "plot", "title": "From metro line", "value": 9000, "unit": "mm", "reference": "DCPR 2034 reg. x"}).json()
    assert new["origin"] == "user" and client.get("/api/rules").json()["edited"] is True
    dp = next(x for x in r["rules"] if x["enforce"] == "rules.plot_clearance_mm.dp_road")
    up = client.put(f"/api/rules/{dp['id']}", json={"value": 5000}).json()
    assert up["origin"] == "edited"
    from substation_retrieval.services import get_services
    assert get_services().settings.get("rules.plot_clearance_mm.dp_road") == 5000      # edit reaches the checks
    assert client.post("/api/rules", json={"section": "nope", "title": "x"}).status_code == 400
    assert client.delete(f"/api/rules/{new['id']}").json()["ok"]
    assert client.delete("/api/rules/missing").status_code == 404
    client.post("/api/rules/reset")
    assert client.get("/api/rules").json()["edited"] is False


def test_geometry_has_clearance_table(client):
    d = client.get("/api/documents").json()[0]["doc_id"]
    g = client.get(f"/api/documents/{d}/geometry").json()
    cl = [c for s in g["substations"] for c in s["clearances"]]
    assert all({"a", "b", "kind", "status", "required_mm"} <= set(c) for c in cl)
    assert all(c["status"] in ("pass", "fail", "no rule") for c in cl)


def test_review_clearances_carry_rule_status(client):
    d = client.get("/api/documents").json()[0]["doc_id"]
    r = client.get(f"/api/documents/{d}/review").json()
    assert all(c["status"] in ("pass", "fail", "info") for c in r["clearances"])
    assert {c["kind"] for c in r["clearances"]} <= {"equipment_gap", "wall_gap", "ceiling_clearance", "plot_clearance"}


def test_review_marks_roundtrip(client):
    d = client.get("/api/documents").json()[0]["doc_id"]
    assert client.get(f"/api/documents/{d}/review-marks").json()["marks"] == {}
    m = client.put(f"/api/documents/{d}/review-marks/S1:RMU-1", json={"verdict": "wrong", "note": "box is on the wrong unit"}).json()["marks"]
    assert m["S1:RMU-1"]["verdict"] == "wrong"
    m = client.put(f"/api/documents/{d}/review-marks", json={"item_ids": ["a", "b"], "verdict": "correct"}).json()["marks"]
    assert {k for k, v in m.items() if v["verdict"] == "correct"} == {"a", "b"} and "S1:RMU-1" in m
    assert client.put(f"/api/documents/{d}/review-marks/a", json={"verdict": "maybe"}).status_code == 400
    m = client.put(f"/api/documents/{d}/review-marks/a", json={"verdict": None}).json()["marks"]
    assert "a" not in m
