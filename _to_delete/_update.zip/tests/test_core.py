from substation_retrieval.core import catalogue
from substation_retrieval.core.ontology import equipment_class, leaf_classes, wu_palmer
from substation_retrieval.geometry import polygons as P
from substation_retrieval.geometry.als import Item, RoomGeom, als, align

W = {"footprint": 3, "equipment": 3, "structure": 3, "cutouts": 2, "doors": 2, "height": 2, "trench": 1, "louvres": 0.5, "site": 1}


def test_wu_palmer_orders_similarity():
    assert wu_palmer("transformer", "transformer") == 1.0
    assert wu_palmer("transformer_dry", "transformer_oil") > wu_palmer("transformer_dry", "rmu") > 0
    assert wu_palmer("transformer", "door") == 0.0
    assert len(leaf_classes()) >= 27


def test_equipment_class():
    assert equipment_class("transformer", "DT-1", "dry") == "transformer_dry"
    assert equipment_class("unitised_css") == "packaged"
    assert equipment_class("acdb") == "aux"


def test_catalogue_rating_unique_and_ambiguous():
    r = catalogue.infer_rating("transformer", 2460, 2200, 2400, 5430)
    assert r["kva"] == 1500 and r["unique"]
    amb = catalogue.infer_rating("transformer", None, None, None, None)
    assert amb["kva"] is None
    assert catalogue.parse_weight_kg("10 MT") == 10000


def _room(L, B, shift=(0, 0), rot=0, mirror=False):
    o = P.poly(P.rect(0, 0, L, B))
    eq = P.poly(P.rect(500, 500, 2960, 2700))
    rg = RoomGeom(outline=o, groups={"equipment": [Item("transformer", eq, {"H_mm": 2400, "id": "DT"})]})
    if rot or mirror or shift != (0, 0):
        c = (o.centroid.x, o.centroid.y)
        rg.outline = P.apply_pose(o, rot, mirror, c, *shift)
        rg.groups["equipment"][0].geom = P.apply_pose(eq, rot, mirror, c, *shift)
    return rg


def test_alignment_recovers_rotation_and_mirror():
    q = _room(11000, 8000)
    r = _room(11000, 8000, shift=(3000, -2000), rot=90, mirror=True)
    pose = align(q, r)
    assert pose.iou > 0.97 and pose.containment > 0.97


def test_als_presence_rule_and_identity():
    q = _room(11000, 8000)
    res = als(q, _room(11000, 8000, rot=180), W)
    assert res.score > 0.9
    assert set(res.components) == {"footprint", "equipment"}
    q2 = RoomGeom(outline=P.poly(P.rect(0, 0, 11000, 8000)))
    res2 = als(q2, _room(6000, 4000), W)
    assert "equipment" not in res2.components and res2.components["footprint"] < 0.6


def test_measured_clearances_and_rule_match():
    from substation_retrieval.core.rules import match_equipment, required_gap
    from substation_retrieval.extraction.normalise import measured_clearances
    from substation_retrieval.api.clearances import clearance_table
    import json
    from pathlib import Path
    eq = [{"id": "A", "label": "RMU-1", "equipment_type": "rmu", "polygon_mm": [[1000, 1000], [2200, 1000], [2200, 2100], [1000, 2100]]},
          {"id": "B", "label": "DT-1", "equipment_type": "transformer", "kva": 630, "polygon_mm": [[3000, 1000], [5250, 1000], [5250, 2900], [3000, 2900]]}]
    room = [[0, 0], [8000, 0], [8000, 5000], [0, 5000]]
    c = measured_clearances(eq, room)
    ab = next(x for x in c if x["relation"] == "equipment_gap")
    assert ab["mm"] == 800 and ab["p"][0] == 2200 and ab["q"][0] == 3000
    assert next(x for x in c if x["b"] == "wall_W" and x["a"] == "RMU-1")["mm"] == 1000
    rules = json.loads((Path(__file__).resolve().parents[1] / "config" / "rules_seed.json").read_text())["rules"]
    ra, rb = match_equipment(rules, eq[0]), match_equipment(rules, eq[1])
    assert ra and "way" in ra["title"].lower() and rb and "KVA" in rb["title"]
    assert required_gap(ra, rb) == 750
    sub = {"name": "CSS-1", "electrical": {"equipment": eq}, "clearances": c + [{"a": "RMU-1", "b": "wall_west", "mm": 1000, "source": "plan dim"}]}
    t = clearance_table(sub, rules)
    pair = next(r for r in t if r["kind"] == "equipment")
    assert pair["status"] == "pass" and pair["measured_mm"] == 800 and pair["required_mm"] == 750
    west = next(r for r in t if r["kind"] == "wall" and "W" in (r["b"] or "") + (r["a"] or ""))
    assert west["drawn_mm"] == 1000 and west["measured_mm"] == 1000          # drawn 'wall_west' merged with measured 'wall_W'
